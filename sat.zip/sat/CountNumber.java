import java.io.FileInputStream;

public class CountNumber {
    public static void main(String[] args) {
        try {
            FileInputStream fis = new FileInputStream("sample.txt");

            int count = 0;
            while (fis.read() != -1) {
                count++;
            }

            fis.close();
            System.out.println("Total characters = " + count);
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}