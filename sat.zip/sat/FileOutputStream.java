import java.io.FileOutputStream;

public class FileOutputStream {
    public static void main(String[] args) {
        try {
            FileOutputStream fos = new FileOutputStream("sample.txt");
            String text = "Hello Java";
            fos.write(text.getBytes());
            fos.close();
            System.out.println("Data written successfully");
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}