import java.io.FileInputStream;
import java.io.FileOutputStream;

public class OneFile {
    public static void main(String[] args) {
        try {
            FileInputStream fis = new FileInputStream("sample.txt");
            FileOutputStream fos = new FileOutputStream("copy.txt");

            int i;
            while ((i = fis.read()) != -1) {
                fos.write(i);
            }

            fis.close();
            fos.close();

            System.out.println("File copied successfully");
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}