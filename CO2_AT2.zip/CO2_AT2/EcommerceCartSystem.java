import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

class CartItem {
    private String productId;
    private String productName;
    private int quantity;
    private double price;

    public CartItem(String productId, String productName, int quantity, double price) {
        this.productId = productId;
        this.productName = productName;
        this.quantity = quantity;
        this.price = price;
    }

    public String getProductId() {
        return productId;
    }

    public String getProductName() {
        return productName;
    }

    public int getQuantity() {
        return quantity;
    }

    public double getPrice() {
        return price;
    }

    public double getTotalPrice() {
        return quantity * price;
    }

    @Override
    public String toString() {
        return String.format("Product: %s (ID: %s) | Qty: %d | Price: $%.2f | Total: $%.2f",
                productName, productId, quantity, price, getTotalPrice());
    }
}

public class EcommerceCartSystem {
    public static void main(String[] args) {
        // List implementation using ArrayList with Generics
        List<CartItem> cart = new ArrayList<>();

        System.out.println("--- Adding Items to the Cart ---");
        CartItem item1 = new CartItem("P001", "Gaming Laptop", 1, 1200.00);
        CartItem item2 = new CartItem("P002", "Wireless Mouse", 2, 25.00);
        CartItem item3 = new CartItem("P003", "Mechanical Keyboard", 1, 80.00);
        CartItem item4 = new CartItem("P004", "USB-C Hub", 1, 45.00);

        cart.add(item1);
        cart.add(item2);
        cart.add(item3);
        cart.add(item4);
        
        System.out.println("Successfully added " + cart.size() + " items.\n");

        // Displaying cart contents before removal
        System.out.println("--- Current Cart Items ---");
        displayCart(cart);

        // Remove an item (removing "P002" - Wireless Mouse)
        String targetProductId = "P002";
        System.out.println("\n--- Removing Item with ID: " + targetProductId + " ---");
        
        Iterator<CartItem> iterator = cart.iterator();
        boolean removed = false;
        while (iterator.hasNext()) {
            CartItem item = iterator.next();
            if (item.getProductId().equals(targetProductId)) {
                iterator.remove(); // Safely remove the element using the iterator
                System.out.println("Removed: " + item.getProductName());
                removed = true;
                break;
            }
        }
        if (!removed) {
            System.out.println("Product with ID " + targetProductId + " not found in the cart.");
        }

        // Displaying cart contents after removal
        System.out.println("\n--- Final Cart Items ---");
        displayCart(cart);
    }

    // Method to display cart items using Iterator
    private static void displayCart(List<CartItem> cart) {
        if (cart.isEmpty()) {
            System.out.println("Your cart is empty.");
            return;
        }

        double grandTotal = 0.0;
        Iterator<CartItem> displayIterator = cart.iterator();
        
        while (displayIterator.hasNext()) {
            CartItem item = displayIterator.next();
            System.out.println(item);
            grandTotal += item.getTotalPrice();
        }
        
        System.out.printf("Total Cart Value: $%.2f\n", grandTotal);
    }
}
