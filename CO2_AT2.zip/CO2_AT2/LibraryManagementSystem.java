import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

class Book {
    private String isbn;
    private String title;
    private String author;

    public Book(String isbn, String title, String author) {
        this.isbn = isbn;
        this.title = title;
        this.author = author;
    }

    public String getIsbn() {
        return isbn;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    @Override
    public String toString() {
        return "Book [ISBN: " + isbn + " | Title: \"" + title + "\" | Author: " + author + "]";
    }
}

public class LibraryManagementSystem {
    public static void main(String[] args) {
        // Map to store books mapped by their unique ISBN String
        Map<String, Book> bookCatalog = new HashMap<>();

        // 1. Insert book details
        System.out.println("--- Inserting Book Details ---");
        Book b1 = new Book("978-0134685991", "Effective Java", "Joshua Bloch");
        Book b2 = new Book("978-0132350884", "Clean Code", "Robert C. Martin");
        Book b3 = new Book("978-0596009205", "Head First Java", "Kathy Sierra");

        bookCatalog.put(b1.getIsbn(), b1);
        bookCatalog.put(b2.getIsbn(), b2);
        bookCatalog.put(b3.getIsbn(), b3);
        System.out.println("Inserted 3 books into the library system.\n");

        // 2. Retrieve a book using ISBN
        String searchIsbn = "978-0132350884";
        System.out.println("--- Retrieving Book with ISBN: " + searchIsbn + " ---");
        if (bookCatalog.containsKey(searchIsbn)) {
            Book retrievedBook = bookCatalog.get(searchIsbn);
            System.out.println("Found: " + retrievedBook);
        } else {
            System.out.println("Book with ISBN " + searchIsbn + " not found.");
        }
        System.out.println();

        // 3. Display all books in the library
        System.out.println("--- Displaying All Books in Catalog ---");
        Iterator<Map.Entry<String, Book>> entryIterator = bookCatalog.entrySet().iterator();
        while (entryIterator.hasNext()) {
            Map.Entry<String, Book> entry = entryIterator.next();
            String isbnKey = entry.getKey();
            Book bookValue = entry.getValue();
            System.out.println("Key (ISBN): " + isbnKey + " => " + bookValue);
        }
    }
}
