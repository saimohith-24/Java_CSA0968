import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

class Employee {
    private int id;
    private String name;
    private double salary;

    public Employee(int id, String name, double salary) {
        this.id = id;
        this.name = name;
        this.salary = salary;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public double getSalary() {
        return salary;
    }

    @Override
    public String toString() {
        return String.format("Employee (ID: %d, Name: %s, Salary: $%.2f)", id, name, salary);
    }
}

public class EmployeeDataProcessing {
    public static void main(String[] args) {
        // List with Generics to store Employee objects
        List<Employee> employeeList = new ArrayList<>();

        // Store employee objects
        System.out.println("--- Storing Employee Records ---");
        employeeList.add(new Employee(101, "Alice", 60000.0));
        employeeList.add(new Employee(102, "Bob", 45000.0));
        employeeList.add(new Employee(103, "Charlie", 72000.0));
        employeeList.add(new Employee(104, "David", 30000.0));
        employeeList.add(new Employee(105, "Emma", 55000.0));

        System.out.println("Stored " + employeeList.size() + " employee records.\n");

        // Display all records first for verification
        System.out.println("--- All Employees ---");
        for (Employee emp : employeeList) {
            System.out.println(emp);
        }
        System.out.println();

        // Display employees with salary > 50,000 using Iterator
        System.out.println("--- Employees with Salary > $50,000 (using Iterator) ---");
        Iterator<Employee> iterator = employeeList.iterator();
        
        int matchCount = 0;
        while (iterator.hasNext()) {
            Employee emp = iterator.next();
            if (emp.getSalary() > 50000.0) {
                System.out.println(emp);
                matchCount++;
            }
        }
        System.out.println("Total matching employees: " + matchCount);
    }
}
