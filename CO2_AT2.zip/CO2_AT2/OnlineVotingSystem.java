import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class OnlineVotingSystem {
    // Set to store unique Voter IDs who have already cast a vote
    private Set<String> votedVoters;
    
    // Map to store Candidate Name -> Total Vote Count
    private Map<String, Integer> candidateVotes;

    public OnlineVotingSystem() {
        this.votedVoters = new HashSet<>();
        this.candidateVotes = new HashMap<>();
    }

    /**
     * Attempts to record a vote from a voter.
     * Prevents duplicate voting.
     * 
     * @param voterId   the unique ID of the voter
     * @param candidate the name of the candidate being voted for
     * @return true if the vote was successfully recorded; false if the voter already voted
     */
    public boolean castVote(String voterId, String candidate) {
        // Prevent duplicate voting by checking the HashSet
        if (votedVoters.contains(voterId)) {
            System.out.println("ALERT: Voter [ID: " + voterId + "] has already voted! Vote rejected.");
            return false;
        }

        // Record the voter in the HashSet
        votedVoters.add(voterId);

        // Update vote count for candidate in HashMap (efficient count increment)
        candidateVotes.put(candidate, candidateVotes.getOrDefault(candidate, 0) + 1);
        System.out.println("SUCCESS: Vote recorded from [ID: " + voterId + "] for candidate \"" + candidate + "\".");
        return true;
    }

    /**
     * Displays all candidates and their respective vote counts using an Iterator.
     */
    public void displayResults() {
        System.out.println("\n--- Election Results (using Iterator) ---");
        if (candidateVotes.isEmpty()) {
            System.out.println("No votes recorded yet.");
            return;
        }

        Iterator<Map.Entry<String, Integer>> iterator = candidateVotes.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<String, Integer> entry = iterator.next();
            System.out.println("Candidate: \"" + entry.getKey() + "\" | Votes: " + entry.getValue());
        }
        System.out.println("Total Votes Cast: " + votedVoters.size());
    }

    public static void main(String[] args) {
        OnlineVotingSystem votingSystem = new OnlineVotingSystem();

        System.out.println("--- Starting Voting Phase ---");
        // Voter IDs casting votes
        votingSystem.castVote("V101", "Candidate A");
        votingSystem.castVote("V102", "Candidate B");
        votingSystem.castVote("V103", "Candidate A");
        
        // Attempting duplicate vote from V101
        votingSystem.castVote("V101", "Candidate C"); // Should print alert/reject
        
        votingSystem.castVote("V104", "Candidate A");
        votingSystem.castVote("V105", "Candidate B");
        // Attempting duplicate vote from V103
        votingSystem.castVote("V103", "Candidate B"); // Should print alert/reject

        // Display results
        votingSystem.displayResults();
    }
}
