import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

class Student {
    private String id;
    private String name;

    public Student(String id, String name) {
        this.id = id;
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    // Overriding equals to ensure unique students based on their ID
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Student student = (Student) o;
        return Objects.equals(id, student.id);
    }

    // Overriding hashCode to hash unique IDs
    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return "Student(ID: " + id + ", Name: " + name + ")";
    }
}

public class StudentRegistrationSystem {
    public static void main(String[] args) {
        // HashSet to store unique students
        Set<Student> students = new HashSet<>();
        
        // HashMap mapping each Student to a Set of enrolled courses (Generics used)
        Map<Student, Set<String>> studentCourses = new HashMap<>();

        // Creating student objects
        Student s1 = new Student("S101", "Alice");
        Student s2 = new Student("S102", "Bob");
        Student s3 = new Student("S103", "Charlie");
        // Attempting to add a duplicate student with same ID (S101) but different name
        Student s4 = new Student("S101", "Alice Duplicate");

        // 1. Add students to the set
        System.out.println("--- Adding Students to the System ---");
        System.out.println("Adding Alice (S101): " + students.add(s1));
        System.out.println("Adding Bob (S102): " + students.add(s2));
        System.out.println("Adding Charlie (S103): " + students.add(s3));
        System.out.println("Adding Duplicate Alice (S101): " + students.add(s4)); // Should be false
        
        System.out.println("\nTotal Unique Students: " + students.size() + "\n");

        // 2. Map students to courses
        // Enrolling Alice in CS101, CS102
        Set<String> aliceCourses = new HashSet<>();
        aliceCourses.add("CS101");
        aliceCourses.add("CS102");
        studentCourses.put(s1, aliceCourses);

        // Enrolling Bob in CS101, CS104
        Set<String> bobCourses = new HashSet<>();
        bobCourses.add("CS101");
        bobCourses.add("CS104");
        studentCourses.put(s2, bobCourses);

        // Enrolling Charlie in CS102, CS105
        Set<String> charlieCourses = new HashSet<>();
        charlieCourses.add("CS102");
        charlieCourses.add("CS105");
        studentCourses.put(s3, charlieCourses);

        // 3. Display data using Iterator
        System.out.println("--- Student Course Enrollment Records (using Iterator) ---");
        Iterator<Map.Entry<Student, Set<String>>> iterator = studentCourses.entrySet().iterator();
        
        while (iterator.hasNext()) {
            Map.Entry<Student, Set<String>> entry = iterator.next();
            Student student = entry.getKey();
            Set<String> courses = entry.getValue();
            System.out.println(student + " is enrolled in: " + courses);
        }
    }
}
