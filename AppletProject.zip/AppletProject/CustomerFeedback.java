import java.awt.*;
import java.awt.event.*;

public class CustomerFeedback extends Frame implements ActionListener {

    Label nameLabel, feedbackLabel, ratingLabel, resultLabel;
    TextField nameField;
    TextArea feedbackArea;
    Choice ratingChoice;
    Button submitButton;

    public CustomerFeedback() {
        // Set Frame properties
        setTitle("Customer Feedback");
        setSize(400, 450);
        setLayout(new FlowLayout());

        // Handle window closing to allow exit
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                dispose();
                System.exit(0);
            }
        });

        nameLabel = new Label("Customer Name:");
        nameField = new TextField(20);

        feedbackLabel = new Label("Feedback:");
        feedbackArea = new TextArea(4, 20);

        ratingLabel = new Label("Rating:");
        ratingChoice = new Choice();

        ratingChoice.add("1");
        ratingChoice.add("2");
        ratingChoice.add("3");
        ratingChoice.add("4");
        ratingChoice.add("5");

        submitButton = new Button("Submit");
        submitButton.addActionListener(this);

        resultLabel = new Label("");

        add(nameLabel);
        add(nameField);

        add(feedbackLabel);
        add(feedbackArea);

        add(ratingLabel);
        add(ratingChoice);

        add(submitButton);
        add(resultLabel);
    }

    public void actionPerformed(ActionEvent e) {

        String name = nameField.getText();
        String feedback = feedbackArea.getText();
        String rating = ratingChoice.getSelectedItem();

        if(name.isEmpty() || feedback.isEmpty()) {
            resultLabel.setText("Please fill all fields.");
        }
        else {
            resultLabel.setText(
                "Thank You " + name +
                " | Rating: " + rating +
                " | Feedback Submitted Successfully!"
            );
        }
    }

    public static void main(String[] args) {
        CustomerFeedback app = new CustomerFeedback();
        app.setVisible(true);
    }
}