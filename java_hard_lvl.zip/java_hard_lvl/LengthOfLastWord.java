public class LengthOfLastWord {
    public static int lengthOfLastWord(String s) {
        if (s == null) {
            return 0;
        }
        s = s.trim();
        int lastSpace = s.lastIndexOf(' ');
        return s.length() - 1 - lastSpace;
    }

    public static void main(String[] args) {
        String s = "Hello World";
        System.out.println("Input: s = \"" + s + "\"");
        System.out.println("Output: " + lengthOfLastWord(s));

        String s2 = "   fly me   to   the moon  ";
        System.out.println("Input: s = \"" + s2 + "\"");
        System.out.println("Output: " + lengthOfLastWord(s2));
    }
}
