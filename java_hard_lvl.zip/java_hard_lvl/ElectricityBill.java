import java.util.Scanner;

public class ElectricityBill {
    private String consumerNo;
    private String consumerName;
    private double prevReading;
    private double currReading;

    public ElectricityBill(String consumerNo, String consumerName, double prevReading, double currReading) {
        this.consumerNo = consumerNo;
        this.consumerName = consumerName;
        this.prevReading = prevReading;
        this.currReading = currReading;
    }

    public double getUnitsConsumed() {
        return Math.max(0, currReading - prevReading);
    }

    public double calculateBillAmount() {
        double units = getUnitsConsumed();
        double billAmount = 0;

        if (units <= 100) {
            billAmount = units * 1.00;
        } else if (units <= 200) {
            billAmount = (100 * 1.00) + (units - 100) * 2.50;
        } else if (units <= 500) {
            billAmount = (100 * 1.00) + (100 * 2.50) + (units - 200) * 4.00;
        } else {
            // For units > 500, we apply a standard rate of Rs. 6.00 per unit
            billAmount = (100 * 1.00) + (100 * 2.50) + (300 * 4.00) + (units - 500) * 6.00;
        }

        return billAmount;
    }

    public void displayBill() {
        System.out.println("\n============ ELECTRICITY BILL ============");
        System.out.println("Consumer No.       : " + consumerNo);
        System.out.println("Consumer Name     : " + consumerName);
        System.out.println("Previous Reading  : " + prevReading + " units");
        System.out.println("Current Reading   : " + currReading + " units");
        System.out.println("Units Consumed    : " + getUnitsConsumed() + " units");
        System.out.printf("Total Bill Amount : Rs. %.2f\n", calculateBillAmount());
        System.out.println("==========================================");
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter Consumer Number: ");
        String consumerNo = scanner.nextLine();

        System.out.print("Enter Consumer Name: ");
        String consumerName = scanner.nextLine();

        System.out.print("Enter Previous Month Reading: ");
        double prevReading = scanner.nextDouble();

        System.out.print("Enter Current Month Reading: ");
        double currReading = scanner.nextDouble();

        ElectricityBill bill = new ElectricityBill(consumerNo, consumerName, prevReading, currReading);
        bill.displayBill();

        scanner.close();
    }
}
