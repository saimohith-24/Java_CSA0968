import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class CommonElements {
    public static int[] findCommonElements(int[] arr1, int[] arr2) {
        Set<Integer> set = new LinkedHashSet<>();
        for (int num : arr1) {
            set.add(num);
        }

        List<Integer> common = new ArrayList<>();
        // To avoid duplicates in output and maintain order of arr2 elements
        Set<Integer> added = new LinkedHashSet<>();
        for (int num : arr2) {
            if (set.contains(num) && !added.contains(num)) {
                common.add(num);
                added.add(num);
            }
        }

        int[] result = new int[common.size()];
        for (int i = 0; i < common.size(); i++) {
            result[i] = common.get(i);
        }
        return result;
    }

    public static void main(String[] args) {
        int[] arr1 = {1, 2, 3, 4};
        int[] arr2 = {2, 4, 5, 6, 7};
        
        System.out.println("Array 1: " + Arrays.toString(arr1));
        System.out.println("Array 2: " + Arrays.toString(arr2));
        
        int[] common = findCommonElements(arr1, arr2);
        System.out.println("Common elements: " + Arrays.toString(common));
    }
}
