import java.util.Scanner;

interface ProgrammingSubjects {
    double getPythonMarks();
    double getCProgrammingMarks();
}

interface ScienceMathSubjects {
    double getMathematicsMarks();
    double getPhysicsMarks();
    double getChemistryMarks();
}

interface EthicsSubjects {
    double getProfessionalEthicsMarks();
}

class Student implements ProgrammingSubjects, ScienceMathSubjects, EthicsSubjects {
    private final double python;
    private final double cProgramming;
    private final double mathematics;
    private final double physics;
    private final double chemistry;
    private final double professionalEthics;

    public Student(double python, double cProgramming, double mathematics, double physics, double chemistry, double professionalEthics) {
        this.python = python;
        this.cProgramming = cProgramming;
        this.mathematics = mathematics;
        this.physics = physics;
        this.chemistry = chemistry;
        this.professionalEthics = professionalEthics;
    }

    @Override
    public double getPythonMarks() {
        return python;
    }

    @Override
    public double getCProgrammingMarks() {
        return cProgramming;
    }

    @Override
    public double getMathematicsMarks() {
        return mathematics;
    }

    @Override
    public double getPhysicsMarks() {
        return physics;
    }

    @Override
    public double getChemistryMarks() {
        return chemistry;
    }

    @Override
    public double getProfessionalEthicsMarks() {
        return professionalEthics;
    }

    public double calculateTotal() {
        return getPythonMarks() + getCProgrammingMarks() + getMathematicsMarks() + getPhysicsMarks() + getChemistryMarks() + getProfessionalEthicsMarks();
    }

    public double calculateAggregate() {
        return calculateTotal() / 6.0;
    }

    public String determineGradeClass() {
        double aggregate = calculateAggregate();
        if (aggregate > 75) {
            return "DISTINCTION";
        } else if (aggregate >= 60 && aggregate <= 75) {
            return "FIRST DIVISION";
        } else if (aggregate >= 50 && aggregate < 60) {
            return "SECOND DIVISION";
        } else if (aggregate >= 40 && aggregate < 50) {
            return "THIRD DIVISION";
        } else {
            return "FAIL";
        }
    }
}

public class StudentGrades {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the marks in python: ");
        double python = scanner.nextDouble();

        System.out.print("Enter the marks in c programming: ");
        double cProgramming = scanner.nextDouble();

        System.out.print("Enter the marks in Mathematics: ");
        double mathematics = scanner.nextDouble();

        System.out.print("Enter the marks in Physics: ");
        double physics = scanner.nextDouble();

        System.out.print("Enter the marks in Chemistry: ");
        double chemistry = scanner.nextDouble();

        System.out.print("Enter the marks in Professional Ethics: ");
        double professionalEthics = scanner.nextDouble();

        Student student = new Student(python, cProgramming, mathematics, physics, chemistry, professionalEthics);

        double total = student.calculateTotal();
        double aggregate = student.calculateAggregate();
        String gradeClass = student.determineGradeClass();

        // Print output formatted as in the example
        // Total is printed as integer if it's a whole number
        if (total == (long) total) {
            System.out.println("Total= " + (long) total);
        } else {
            System.out.printf("Total= %.2f\n", total);
        }
        System.out.printf("Aggregate = %.2f\n", aggregate);
        System.out.println("Class: " + gradeClass);

        scanner.close();
    }
}
