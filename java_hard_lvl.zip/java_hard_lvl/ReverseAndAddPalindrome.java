import java.util.Scanner;

public class ReverseAndAddPalindrome {
    public static long reverseNumber(long num) {
        long rev = 0;
        while (num > 0) {
            rev = rev * 10 + (num % 10);
            num /= 10;
        }
        return rev;
    }

    public static boolean isPalindrome(long num) {
        return num == reverseNumber(num);
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter input number: ");
        if (!scanner.hasNextLine()) {
            scanner.close();
            return;
        }
        String inputStr = scanner.nextLine().trim();
        scanner.close();

        // Validation: must be a non-negative integer
        try {
            if (inputStr.contains(".")) {
                System.out.println("Invalid input");
                return;
            }
            long number = Long.parseLong(inputStr);
            if (number < 0) {
                System.out.println("Invalid input");
                return;
            }

            if (isPalindrome(number)) {
                System.out.println(number + " (Palindrome)");
                return;
            }

            long current = number;
            int iterations = 0;
            boolean firstStep = true;
            
            while (iterations < 100) {
                long rev = reverseNumber(current);
                long sum = current + rev;
                boolean isPal = isPalindrome(sum);

                if (firstStep) {
                    System.out.println(current + " (Input Number) + " + rev + " (Reverse Of Input Number) = " + sum + (isPal ? " (Palindrome)" : ""));
                    firstStep = false;
                } else {
                    System.out.println(current + " + " + rev + " = " + sum + (isPal ? " (Palindrome)" : ""));
                }

                if (isPal) {
                    break;
                }

                current = sum;
                iterations++;
            }

            if (iterations >= 100) {
                System.out.println("No palindrome reached within 100 iterations.");
            }

        } catch (NumberFormatException e) {
            System.out.println("Invalid input");
        }
    }
}
