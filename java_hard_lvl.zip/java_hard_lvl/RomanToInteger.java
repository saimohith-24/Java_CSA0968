import java.util.HashMap;
import java.util.Map;

public class RomanToInteger {
    public static int romanToInt(String s) {
        if (s == null || s.length() == 0) {
            return 0;
        }

        Map<Character, Integer> romanMap = new HashMap<>();
        romanMap.put('I', 1);
        romanMap.put('V', 5);
        romanMap.put('X', 10);
        romanMap.put('L', 50);
        romanMap.put('C', 100);
        romanMap.put('D', 500);
        romanMap.put('M', 1000);

        int total = 0;
        int length = s.length();
        for (int i = 0; i < length; i++) {
            int currentVal = romanMap.get(s.charAt(i));
            if (i + 1 < length) {
                int nextVal = romanMap.get(s.charAt(i + 1));
                if (currentVal < nextVal) {
                    total -= currentVal;
                } else {
                    total += currentVal;
                }
            } else {
                total += currentVal;
            }
        }
        return total;
    }

    public static void main(String[] args) {
        String[] testCases = {"III", "LVIII", "MCMXCIV"};
        for (String test : testCases) {
            System.out.println("Roman: " + test + " -> Integer: " + romanToInt(test));
        }
    }
}
