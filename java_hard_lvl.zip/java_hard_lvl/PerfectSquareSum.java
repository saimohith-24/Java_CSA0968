import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class PerfectSquareSum {
    public static boolean isPerfectSquare(int n) {
        if (n < 0) {
            return false;
        }
        int root = (int) Math.sqrt(n);
        return root * root == n;
    }

    public static int getDigitSum(int n) {
        n = Math.abs(n);
        int sum = 0;
        while (n > 0) {
            sum += n % 10;
            n /= 10;
        }
        return sum;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try {
            System.out.print("Enter lower range: ");
            if (!scanner.hasNextInt()) {
                System.out.println("Invalid input");
                scanner.close();
                return;
            }
            int lower = scanner.nextInt();

            System.out.print("Enter upper range: ");
            if (!scanner.hasNextInt()) {
                System.out.println("Invalid input");
                scanner.close();
                return;
            }
            int upper = scanner.nextInt();

            if (lower > upper) {
                System.out.println("[]");
                scanner.close();
                return;
            }

            List<Integer> result = new ArrayList<>();
            // We only need to check non-negative numbers for perfect squares
            int start = Math.max(0, lower);
            for (int i = start; i <= upper; i++) {
                if (isPerfectSquare(i) && getDigitSum(i) < 10) {
                    result.add(i);
                }
            }

            System.out.println(result);

        } catch (Exception e) {
            System.out.println("Invalid input");
        }

        scanner.close();
    }
}
