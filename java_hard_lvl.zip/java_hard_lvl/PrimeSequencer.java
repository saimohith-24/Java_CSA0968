import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class PrimeSequencer {
    public static boolean isPrime(int num) {
        if (num <= 1) {
            return false;
        }
        if (num == 2 || num == 3) {
            return true;
        }
        if (num % 2 == 0 || num % 3 == 0) {
            return false;
        }
        for (int i = 5; i * i <= num; i += 6) {
            if (num % i == 0 || num % (i + 2) == 0) {
                return false;
            }
        }
        return true;
    }

    public static String getOrdinalSuffix(int n) {
        if (n % 100 >= 11 && n % 100 <= 13) {
            return "th";
        }
        switch (n % 10) {
            case 1: return "st";
            case 2: return "nd";
            case 3: return "rd";
            default: return "th";
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("N = ");
        if (!scanner.hasNextLine()) {
            scanner.close();
            return;
        }
        String inputStr = scanner.nextLine().trim();
        scanner.close();

        // Validate: must be a positive integer
        try {
            if (inputStr.contains(".")) {
                System.out.println("Invalid input");
                return;
            }
            int n = Integer.parseInt(inputStr);
            if (n <= 0) {
                System.out.println("Invalid input");
                return;
            }

            // Find first 2 * n prime numbers
            List<Integer> primes = new ArrayList<>();
            int current = 2;
            while (primes.size() < 2 * n) {
                if (isPrime(current)) {
                    primes.add(current);
                }
                current++;
            }

            int nthPrime = primes.get(n - 1);
            String suffix = getOrdinalSuffix(n);
            System.out.println(n + suffix + " Prime number is " + nthPrime);

            StringBuilder nextPrimesStr = new StringBuilder();
            for (int i = n; i < 2 * n; i++) {
                nextPrimesStr.append(primes.get(i));
                if (i < 2 * n - 1) {
                    nextPrimesStr.append(", ");
                }
            }
            System.out.println(n + " prime numbers after " + nthPrime + " are: " + nextPrimesStr.toString());

        } catch (NumberFormatException e) {
            System.out.println("Invalid input");
        }
    }
}
