import java.util.Arrays;

public class KWeakestRows {
    public static int[] kWeakestRows(int[][] mat, int k) {
        int m = mat.length;
        int[][] rowStrength = new int[m][2];

        for (int i = 0; i < m; i++) {
            int soldiers = 0;
            for (int val : mat[i]) {
                if (val == 1) {
                    soldiers++;
                } else {
                    break; // since soldiers are to the left, we can stop at first civilian
                }
            }
            rowStrength[i][0] = soldiers;
            rowStrength[i][1] = i; // original index
        }

        // Sort based on strength first, then by index if strengths are equal
        Arrays.sort(rowStrength, (a, b) -> {
            if (a[0] != b[0]) {
                return Integer.compare(a[0], b[0]);
            } else {
                return Integer.compare(a[1], b[1]);
            }
        });

        int[] result = new int[k];
        for (int i = 0; i < k; i++) {
            result[i] = rowStrength[i][1];
        }
        return result;
    }

    public static void main(String[] args) {
        int[][] mat1 = {
            {1, 1, 0, 0, 0},
            {1, 1, 1, 1, 0},
            {1, 0, 0, 0, 0},
            {1, 1, 0, 0, 0},
            {1, 1, 1, 1, 1}
        };
        int k1 = 3;
        System.out.println("Output 1: " + Arrays.toString(kWeakestRows(mat1, k1)));

        int[][] mat2 = {
            {1, 0, 0, 0},
            {1, 1, 1, 1},
            {1, 0, 0, 0},
            {1, 0, 0, 0}
        };
        int k2 = 2;
        System.out.println("Output 2: " + Arrays.toString(kWeakestRows(mat2, k2)));
    }
}
