import java.util.Scanner;

class Customer {
    private String accountNo;
    private String accName;
    private double balance;

    public Customer(String accountNo, String accName, double initialBalance) {
        this.accountNo = accountNo;
        this.accName = accName;
        this.balance = initialBalance;
    }

    public synchronized void withdraw(double amount) {
        System.out.printf("Attempting to withdraw: %s (Current Balance: %s)\n", formatVal(amount), formatVal(balance));
        while (balance < amount) {
            System.out.println("Insufficient balance. Waiting for deposit...");
            try {
                wait();
            } catch (InterruptedException e) {
                System.out.println("Withdrawal thread interrupted.");
                Thread.currentThread().interrupt();
                return;
            }
        }
        balance -= amount;
        System.out.println("Withdraw operation success, balance amount " + formatVal(balance));
    }

    public synchronized void deposit(double amount) {
        System.out.println("Depositing: " + formatVal(amount));
        balance += amount;
        System.out.println("Deposit success. New Balance: " + formatVal(balance));
        notifyAll();
    }

    private String formatVal(double val) {
        if (val == (long) val) {
            return String.valueOf((long) val);
        } else {
            return String.format("%.2f", val);
        }
    }
}

public class SynchronizedCustomer {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter withdraw amount and deposit amount (e.g. 12000, 3000): ");
        if (!scanner.hasNextLine()) {
            scanner.close();
            return;
        }
        String line = scanner.nextLine().trim();
        scanner.close();

        double withdrawAmt = 0;
        double depositAmt = 0;

        // Parse inputs which may be separated by comma or space
        try {
            String[] parts;
            if (line.contains(",")) {
                parts = line.split(",");
            } else {
                parts = line.split("\\s+");
            }

            if (parts.length < 2) {
                System.out.println("Invalid input. Please provide both withdraw and deposit amounts.");
                return;
            }

            withdrawAmt = Double.parseDouble(parts[0].trim());
            depositAmt = Double.parseDouble(parts[1].trim());

            // Validate that amounts are positive numbers
            if (withdrawAmt <= 0 || depositAmt <= 0) {
                System.out.println("Invalid input (Amounts must be positive numeric values)");
                return;
            }

        } catch (NumberFormatException e) {
            System.out.println("Invalid input");
            return;
        }

        // Initialize Customer with 10000 balance
        Customer customer = new Customer("1001", "John Doe", 10000.0);

        // Thread to perform withdrawal
        double finalWithdrawAmt = withdrawAmt;
        Thread withdrawThread = new Thread(() -> {
            customer.withdraw(finalWithdrawAmt);
        });

        // Thread to perform deposit
        double finalDepositAmt = depositAmt;
        Thread depositThread = new Thread(() -> {
            try {
                // Sleep for 1 second to simulate time lag and ensure withdrawal waits
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            customer.deposit(finalDepositAmt);
        });

        withdrawThread.start();
        depositThread.start();

        try {
            withdrawThread.join();
            depositThread.join();
        } catch (InterruptedException e) {
            System.out.println("Main thread interrupted.");
        }
    }
}
