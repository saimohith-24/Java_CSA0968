import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class FactorsCalculator {
    public static String getOrdinalSuffix(int n) {
        if (n % 100 >= 11 && n % 100 <= 13) {
            return "th";
        }
        switch (n % 10) {
            case 1: return "st";
            case 2: return "nd";
            case 3: return "rd";
            default: return "th";
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try {
            System.out.print("Given Number: ");
            if (!scanner.hasNextInt()) {
                System.out.println("Invalid input");
                scanner.close();
                return;
            }
            int number = scanner.nextInt();

            System.out.print("N: ");
            if (!scanner.hasNextInt()) {
                System.out.println("Invalid input");
                scanner.close();
                return;
            }
            int n = scanner.nextInt();

            // Validate constraints
            if (number == 0) {
                System.out.println("Invalid input (0 has infinite factors)");
                scanner.close();
                return;
            }
            if (n <= 0) {
                System.out.println("Invalid input (N must be a positive integer)");
                scanner.close();
                return;
            }

            int absNum = Math.abs(number);
            List<Integer> factors = new ArrayList<>();
            for (int i = 1; i <= absNum; i++) {
                if (absNum % i == 0) {
                    factors.add(i);
                }
            }

            System.out.println("Number of factors = " + factors.size());

            String suffix = getOrdinalSuffix(n);
            if (n > factors.size()) {
                System.out.println(n + suffix + " factor of " + number + " does not exist");
            } else {
                System.out.println(n + suffix + " factor of " + number + " = " + factors.get(n - 1));
            }

        } catch (Exception e) {
            System.out.println("Invalid input");
        }

        scanner.close();
    }
}
