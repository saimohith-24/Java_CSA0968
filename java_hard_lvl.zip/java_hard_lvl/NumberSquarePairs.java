import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class NumberSquarePairs {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try {
            System.out.print("Enter lower range: ");
            if (!scanner.hasNextInt()) {
                System.out.println("Invalid input");
                scanner.close();
                return;
            }
            int lower = scanner.nextInt();

            System.out.print("Enter upper range: ");
            if (!scanner.hasNextInt()) {
                System.out.println("Invalid input");
                scanner.close();
                return;
            }
            int upper = scanner.nextInt();

            if (lower > upper) {
                System.out.println("[]");
                scanner.close();
                return;
            }

            List<String> pairs = new ArrayList<>();
            for (int i = lower; i <= upper; i++) {
                // Cast square to long to prevent overflow for large numbers
                long sq = (long) i * i;
                pairs.add("(" + i + ", " + sq + ")");
            }

            System.out.println(pairs);

        } catch (Exception e) {
            System.out.println("Invalid input");
        }

        scanner.close();
    }
}
