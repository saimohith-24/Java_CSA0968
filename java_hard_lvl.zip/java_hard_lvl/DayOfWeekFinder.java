import java.time.LocalDate;
import java.time.format.TextStyle;
import java.util.Locale;
import java.util.Scanner;

public class DayOfWeekFinder {
    public static String getDayOfWeek(int day, int month, int year) {
        try {
            LocalDate date = LocalDate.of(year, month, day);
            // Format as Title Case: e.g., "Saturday"
            return date.getDayOfWeek().getDisplayName(TextStyle.FULL, Locale.ENGLISH);
        } catch (Exception e) {
            return "Invalid Date";
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try {
            System.out.print("Enter day: ");
            int day = scanner.nextInt();

            System.out.print("Enter month: ");
            int month = scanner.nextInt();

            System.out.print("Enter year: ");
            int year = scanner.nextInt();

            // Validate constraints (1971 to 2100)
            if (year < 1971 || year > 2100) {
                System.out.println("Invalid input (Year must be between 1971 and 2100)");
                scanner.close();
                return;
            }

            String result = getDayOfWeek(day, month, year);
            System.out.println("Day of the week: " + result);

        } catch (Exception e) {
            System.out.println("Invalid input");
        }

        scanner.close();
    }
}
