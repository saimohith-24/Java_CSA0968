public class RansomNote {
    public static boolean canConstruct(String ransomNote, String magazine) {
        if (ransomNote == null) {
            return true;
        }
        if (magazine == null) {
            return ransomNote.isEmpty();
        }

        int[] charCounts = new int[26];
        for (int i = 0; i < magazine.length(); i++) {
            charCounts[magazine.charAt(i) - 'a']++;
        }

        for (int i = 0; i < ransomNote.length(); i++) {
            int charIndex = ransomNote.charAt(i) - 'a';
            charCounts[charIndex]--;
            if (charCounts[charIndex] < 0) {
                return false;
            }
        }

        return true;
    }

    public static void main(String[] args) {
        String ransomNote = "a";
        String magazine = "b";
        System.out.println("RansomNote: \"" + ransomNote + "\", Magazine: \"" + magazine + "\" -> Can construct? " + canConstruct(ransomNote, magazine));

        String ransomNote2 = "aa";
        String magazine2 = "aab";
        System.out.println("RansomNote: \"" + ransomNote2 + "\", Magazine: \"" + magazine2 + "\" -> Can construct? " + canConstruct(ransomNote2, magazine2));
    }
}
