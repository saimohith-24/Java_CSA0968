import java.util.Scanner;

public class BankAccount {
    private String depositorName;
    private String accountNumber;
    private String accountType; // Savings or Current
    private double balance;

    public BankAccount() {
        this.balance = 10000.0; // Initial balance as assumed in the prompt
    }

    public boolean readAccountDetails(String accNo, String name, String type) {
        // Validate Account Number (must be numeric)
        if (accNo == null || !accNo.matches("\\d+")) {
            System.out.println("Invalid Account Number. It must be numeric.");
            return false;
        }

        // Validate Name (cannot be empty or numeric)
        if (name == null || name.trim().isEmpty() || name.matches("\\d+")) {
            System.out.println("Invalid Depositor Name.");
            return false;
        }

        // Validate Type
        String cleanType = type.trim().toUpperCase();
        if (cleanType.equals("S") || cleanType.equals("SAVINGS")) {
            this.accountType = "Savings";
        } else if (cleanType.equals("C") || cleanType.equals("CURRENT")) {
            this.accountType = "Current";
        } else {
            System.out.println("Invalid Account Type. Use 'Savings' (S) or 'Current' (C).");
            return false;
        }

        this.accountNumber = accNo.trim();
        this.depositorName = name.trim();
        return true;
    }

    public void deposit(double amount) {
        if (amount <= 0) {
            System.out.println("Invalid deposit amount. Amount must be positive.");
            return;
        }
        balance += amount;
        System.out.printf("Successfully deposited Rs. %.2f. New Balance: Rs. %.2f\n", amount, balance);
    }

    public void withdraw(double amount) {
        if (amount <= 0) {
            System.out.println("Invalid withdrawal amount. Amount must be positive.");
            return;
        }
        if (balance - amount < 500.0) {
            System.out.printf("Withdrawal failed. Minimum balance of Rs. 500.00 must be maintained. Current Balance: Rs. %.2f\n", balance);
            return;
        }
        balance -= amount;
        System.out.printf("Successfully withdrew Rs. %.2f. New Balance: Rs. %.2f\n", amount, balance);
    }

    public void displayBalance() {
        System.out.println("\n============ ACCOUNT DETAILS ============");
        System.out.println("Account Number : " + accountNumber);
        System.out.println("Depositor Name : " + depositorName);
        System.out.println("Account Type   : " + accountType);
        System.out.printf("Balance Amount : Rs. %.2f\n", balance);
        System.out.println("=========================================");
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        BankAccount account = new BankAccount();

        System.out.println("--- Create Bank Account ---");
        System.out.print("Enter Account Number: ");
        String accNo = scanner.nextLine();

        System.out.print("Enter Depositor Name: ");
        String name = scanner.nextLine();

        System.out.print("Enter Type of Account (Savings/S or Current/C): ");
        String type = scanner.nextLine();

        if (!account.readAccountDetails(accNo, name, type)) {
            System.out.println("Failed to initialize account due to invalid input.");
            scanner.close();
            return;
        }

        account.displayBalance();

        System.out.print("\nChoose Operation (1 for Deposit, 2 for Withdraw): ");
        if (!scanner.hasNextInt()) {
            System.out.println("Invalid operation.");
            scanner.close();
            return;
        }
        int choice = scanner.nextInt();

        if (choice == 1) {
            System.out.print("Enter amount to deposit: ");
            if (scanner.hasNextDouble()) {
                double amount = scanner.nextDouble();
                account.deposit(amount);
            } else {
                System.out.println("Invalid amount.");
            }
        } else if (choice == 2) {
            System.out.print("Enter amount to withdraw: ");
            if (scanner.hasNextDouble()) {
                double amount = scanner.nextDouble();
                account.withdraw(amount);
            } else {
                System.out.println("Invalid amount.");
            }
        } else {
            System.out.println("Invalid choice.");
        }

        account.displayBalance();
        scanner.close();
    }
}
