import java.util.Scanner;

public class DaysConverter {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the number of days: ");
        if (!scanner.hasNextLine()) {
            scanner.close();
            return;
        }
        String inputStr = scanner.nextLine().trim();
        scanner.close();

        // Validate input: must be a valid non-negative integer
        // If it has decimal point (like 3.6), it is invalid
        // If it is negative (like -365), it is invalid
        // If it contains letters/characters, it is invalid
        try {
            if (inputStr.contains(".")) {
                System.out.println("Invalid input");
                return;
            }
            int totalDays = Integer.parseInt(inputStr);
            if (totalDays < 0) {
                System.out.println("Invalid input");
                return;
            }

            int years = totalDays / 365;
            int remainingAfterYears = totalDays % 365;
            int weeks = remainingAfterYears / 7;
            int days = remainingAfterYears % 7;

            System.out.println("No. of years: " + years);
            System.out.println("No. of weeks: " + weeks);
            System.out.println("No. of days: " + days);

        } catch (NumberFormatException e) {
            System.out.println("Invalid input");
        }
    }
}
