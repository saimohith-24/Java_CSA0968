import java.util.Scanner;

public class TaxCalculator {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the income: ");
        double income = scanner.nextDouble();

        double taxableIncome = 0;
        double tax = 0;

        if (income > 250000) {
            taxableIncome = income - 250000;
        }

        if (taxableIncome <= 0) {
            tax = 0;
        } else if (taxableIncome <= 250000) {
            tax = 0; // The prompt says: "If taxable income is 2,50,001 – 5,00,000 the charge 10% tax"
                     // So taxable income up to 250,000 is not taxed.
        } else if (taxableIncome <= 500000) {
            tax = taxableIncome * 0.10;
        } else if (taxableIncome <= 1000000) {
            tax = taxableIncome * 0.20;
        } else {
            tax = taxableIncome * 0.30;
        }

        // Print output formatted as in the sample
        System.out.println("Taxable Income: " + formatValue(taxableIncome));
        System.out.println("Tax= " + formatValue(tax));

        scanner.close();
    }

    private static String formatValue(double val) {
        if (val == (long) val) {
            return String.valueOf((long) val);
        } else {
            return String.format("%.2f", val);
        }
    }
}
