import java.util.Arrays;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

public class UniquePermutations {
    public static void generatePermutations(char[] chars, boolean[] used, StringBuilder current, Set<String> result) {
        if (current.length() == chars.length) {
            result.add(current.toString());
            return;
        }
        for (int i = 0; i < chars.length; i++) {
            if (used[i]) {
                continue;
            }
            used[i] = true;
            current.append(chars[i]);
            generatePermutations(chars, used, current, result);
            current.deleteCharAt(current.length() - 1);
            used[i] = false;
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Given Number: ");
        if (!scanner.hasNextLine()) {
            scanner.close();
            return;
        }
        String inputStr = scanner.nextLine().trim();
        scanner.close();

        // Validate that it is a valid integer (positive or negative)
        try {
            if (inputStr.contains(".")) {
                System.out.println("Invalid input");
                return;
            }
            int number = Integer.parseInt(inputStr);
            // Treat the number as its absolute value digits for permutation
            String digits = String.valueOf(Math.abs(number));
            char[] chars = digits.toCharArray();
            Arrays.sort(chars);

            Set<String> result = new TreeSet<>();
            boolean[] used = new boolean[chars.length];
            generatePermutations(chars, used, new StringBuilder(), result);

            System.out.println("Permutations are:");
            for (String perm : result) {
                System.out.println(perm);
            }

        } catch (NumberFormatException e) {
            System.out.println("Invalid input");
        }
    }
}
