import java.util.Scanner;

public class StudentUserCount {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try {
            System.out.print("Total Users: ");
            if (!scanner.hasNextInt()) {
                System.out.println("Invalid input");
                scanner.close();
                return;
            }
            int totalUsers = scanner.nextInt();

            System.out.print("Staff Users: ");
            if (!scanner.hasNextInt()) {
                System.out.println("Invalid input");
                scanner.close();
                return;
            }
            int staffUsers = scanner.nextInt();

            // Validate inputs
            if (totalUsers < 0 || staffUsers < 0) {
                System.out.println("Invalid input");
                scanner.close();
                return;
            }

            int nonTeachingStaff = staffUsers / 3;
            int totalStaff = staffUsers + nonTeachingStaff;

            if (totalStaff > totalUsers) {
                System.out.println("Invalid input");
                scanner.close();
                return;
            }

            int studentUsers = totalUsers - totalStaff;
            System.out.println("Student Users: " + studentUsers);

        } catch (Exception e) {
            System.out.println("Invalid input");
        }

        scanner.close();
    }
}
