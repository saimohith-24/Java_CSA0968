public class ParallelThreadsDemo {
    private static final Object lock = new Object();
    private static int current = 1;
    private static final int MAX = 15;

    public static void main(String[] args) {
        Thread t1 = new Thread(new NumberPrinter(1), "Thread-1");
        Thread t2 = new Thread(new NumberPrinter(2), "Thread-2");
        Thread t3 = new Thread(new NumberPrinter(0), "Thread-3");

        System.out.println("Starting three parallel threads to display natural numbers in order:");
        t1.start();
        t2.start();
        t3.start();

        try {
            t1.join();
            t2.join();
            t3.join();
        } catch (InterruptedException e) {
            System.out.println("Main thread interrupted.");
        }
        System.out.println("All threads completed.");
    }

    static class NumberPrinter implements Runnable {
        private final int remainder;

        public NumberPrinter(int remainder) {
            this.remainder = remainder;
        }

        @Override
        public void run() {
            while (true) {
                synchronized (lock) {
                    if (current > MAX) {
                        lock.notifyAll(); // notify other waiting threads to exit
                        break;
                    }
                    if (current % 3 == remainder) {
                        System.out.println(Thread.currentThread().getName() + " printed: " + current);
                        current++;
                        lock.notifyAll();
                    } else {
                        try {
                            // Wait for another thread to increment the number
                            lock.wait(50);
                        } catch (InterruptedException e) {
                            Thread.currentThread().interrupt();
                            break;
                        }
                    }
                }
                // Sleep briefly outside synchronized block to simulate parallel processing overhead
                // and give other threads a fair chance to acquire the lock.
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }
        }
    }
}
