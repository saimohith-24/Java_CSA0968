public class MaxSubarraySum {
    public static void main(String[] args) {
        int[] nums = {-2, 1, -3, 4, -1, 2, 1, -5, 4};
        
        System.out.println("--- Maximum Subarray Sum Demo ---");
        System.out.print("Input array: [");
        for (int i = 0; i < nums.length; i++) {
            System.out.print(nums[i] + (i < nums.length - 1 ? ", " : ""));
        }
        System.out.println("]");
        
        int max = maxSubArray(nums);
        System.out.println("Output: " + max);
        System.out.println("Explanation: The subarray [4, -1, 2, 1] has the largest sum " + max);
    }

    // Kadane's algorithm (O(n) runtime complexity)
    public static int maxSubArray(int[] nums) {
        if (nums == null || nums.length == 0) {
            return 0;
        }

        int maxSoFar = nums[0];
        int currentMax = nums[0];

        for (int i = 1; i < nums.length; i++) {
            // Either extend the previous subarray or start a new one from the current element
            currentMax = Math.max(nums[i], currentMax + nums[i]);
            // Keep track of the overall maximum
            maxSoFar = Math.max(maxSoFar, currentMax);
        }

        return maxSoFar;
    }
}
