import java.util.Arrays;

public class GenericSorterDemo {
    public static void main(String[] args) {
        System.out.println("--- Generic Sorter Demo ---");

        // Sorting Integers
        Integer[] integerArray = {34, 12, 89, 5, 21, 55};
        System.out.println("Original Integer Array: " + Arrays.toString(integerArray));
        GenericSorter<Integer> integerSorter = new GenericSorter<>(integerArray);
        integerSorter.bubbleSort();
        System.out.println("Sorted Integer Array:   " + Arrays.toString(integerSorter.getArray()));

        // Sorting Strings
        String[] stringArray = {"Banana", "Apple", "Grapes", "Pineapple", "Orange"};
        System.out.println("\nOriginal String Array:  " + Arrays.toString(stringArray));
        GenericSorter<String> stringSorter = new GenericSorter<>(stringArray);
        stringSorter.bubbleSort();
        System.out.println("Sorted String Array:    " + Arrays.toString(stringSorter.getArray()));
        
        // Sorting Doubles
        Double[] doubleArray = {3.14, 1.414, 2.718, 0.577, 1.618};
        System.out.println("\nOriginal Double Array:  " + Arrays.toString(doubleArray));
        GenericSorter<Double> doubleSorter = new GenericSorter<>(doubleArray);
        doubleSorter.bubbleSort();
        System.out.println("Sorted Double Array:    " + Arrays.toString(doubleSorter.getArray()));
    }

    // Generic class with type parameters restricted to Comparable types
    static class GenericSorter<T extends Comparable<T>> {
        private T[] array;

        public GenericSorter(T[] array) {
            if (array == null) {
                throw new IllegalArgumentException("Array cannot be null");
            }
            this.array = array.clone();
        }

        public T[] getArray() {
            return this.array;
        }

        // Generic sort method
        public void bubbleSort() {
            int n = array.length;
            for (int i = 0; i < n - 1; i++) {
                for (int j = 0; j < n - i - 1; j++) {
                    // Compare consecutive generic elements
                    if (array[j].compareTo(array[j + 1]) > 0) {
                        // Swap array[j] and array[j+1]
                        T temp = array[j];
                        array[j] = array[j + 1];
                        array[j + 1] = temp;
                    }
                }
            }
        }
    }
}
