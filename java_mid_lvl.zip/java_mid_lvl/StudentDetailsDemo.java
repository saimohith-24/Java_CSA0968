public class StudentDetailsDemo {
    public static void main(String[] args) {
        System.out.println("--- Student Details Program ---");
        
        // Define subject marks for a student
        int[] studentMarks = {88, 92, 79, 95, 84};
        
        // Instantiate Student class using constructor
        Student student = new Student("Sai Mohith", "SAI2026CSE01", studentMarks);
        
        // Display student's records
        student.displayMarksAndStats();
    }

    static class Student {
        private String name;
        private String registerNumber;
        private int[] marks;

        // Constructor assigning the details
        public Student(String name, String registerNumber, int[] marks) {
            this.name = name;
            this.registerNumber = registerNumber;
            if (marks != null && marks.length == 5) {
                this.marks = marks.clone();
            } else {
                this.marks = new int[5]; // Safe default
            }
        }

        // Method to calculate total marks
        public int calculateTotal() {
            int total = 0;
            for (int mark : marks) {
                total += mark;
            }
            return total;
        }

        // Method to calculate average marks
        public double calculateAverage() {
            return calculateTotal() / 5.0;
        }

        // Method to display marks and stats
        public void displayMarksAndStats() {
            System.out.println("Name:            " + name);
            System.out.println("Register Number: " + registerNumber);
            System.out.print("Marks:           ");
            for (int i = 0; i < marks.length; i++) {
                System.out.print(marks[i] + (i < marks.length - 1 ? ", " : ""));
            }
            System.out.println();
            System.out.println("Total Marks:     " + calculateTotal());
            System.out.println("Average Marks:   " + calculateAverage());
        }
    }
}
