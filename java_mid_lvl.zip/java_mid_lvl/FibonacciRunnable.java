import java.util.Scanner;

class FibonacciGenerator implements Runnable {
    private final int limit;

    FibonacciGenerator(int limit) {
        this.limit = limit;
    }

    @Override
    public void run() {
        if (limit <= 0) return;
        
        long a = 0, b = 1;
        for (int i = 1; i <= limit; i++) {
            System.out.print(a + " ");
            long next = a + b;
            a = b;
            b = next;
        }
        System.out.println();
    }
}

public class FibonacciRunnable {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter N: ");
        if (!scanner.hasNextLine()) return;
        String input = scanner.nextLine().trim();

        try {
            double val = Double.parseDouble(input);
            if (val != (int) val || val < 0) {
                System.out.println("Invalid input. N must be a non-negative integer.");
                return;
            }
            int limit = (int) val;
            
            if (limit == 0) {
                System.out.println("No terms to display.");
                return;
            }
            
            FibonacciGenerator generator = new FibonacciGenerator(limit);
            Thread thread = new Thread(generator);
            thread.start();
            try {
                thread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. N must be a non-negative integer.");
        }
    }
}
