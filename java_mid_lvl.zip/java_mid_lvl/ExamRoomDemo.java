import java.util.TreeSet;

public class ExamRoomDemo {
    public static void main(String[] args) {
        System.out.println("--- ExamRoom Simulation ---");
        
        // Initialize ExamRoom with 10 seats
        System.out.println("Initializing ExamRoom with 10 seats...");
        ExamRoom room = new ExamRoom(10);
        
        // Execution trace
        System.out.println("1. seat() -> returned: " + room.seat() + " (Expected: 0)");
        System.out.println("2. seat() -> returned: " + room.seat() + " (Expected: 9)");
        System.out.println("3. seat() -> returned: " + room.seat() + " (Expected: 4)");
        System.out.println("4. seat() -> returned: " + room.seat() + " (Expected: 2)");
        
        System.out.println("5. leave(4)");
        room.leave(4);
        
        System.out.println("6. seat() -> returned: " + room.seat() + " (Expected: 5)");
    }

    static class ExamRoom {
        private final int n;
        private final TreeSet<Integer> seats;

        public ExamRoom(int n) {
            this.n = n;
            this.seats = new TreeSet<>();
        }

        public int seat() {
            if (seats.isEmpty()) {
                seats.add(0);
                return 0;
            }

            int studentSeat = 0;
            int maxDist = seats.first(); // Distance from seat 0 to first occupant

            Integer prev = null;
            for (int curr : seats) {
                if (prev != null) {
                    // Calculate distance to closest occupant for a seat in the middle of prev and curr
                    int dist = (curr - prev) / 2;
                    if (dist > maxDist) {
                        maxDist = dist;
                        studentSeat = prev + dist;
                    }
                }
                prev = curr;
            }

            // Check distance from last occupied seat to the end of the row (n - 1)
            int lastSeatDist = (n - 1) - seats.last();
            if (lastSeatDist > maxDist) {
                studentSeat = n - 1;
            }

            seats.add(studentSeat);
            return studentSeat;
        }

        public void leave(int p) {
            seats.remove(p);
        }
    }
}
