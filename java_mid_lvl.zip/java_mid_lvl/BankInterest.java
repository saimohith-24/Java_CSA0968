import java.util.Scanner;

class Bank {
    public double getRateOfInterest() {
        return 0.0;
    }
}

class SBI extends Bank {
    @Override
    public double getRateOfInterest() {
        return 8.4;
    }
}

class ICICI extends Bank {
    @Override
    public double getRateOfInterest() {
        return 7.3;
    }
}

class AXIS extends Bank {
    @Override
    public double getRateOfInterest() {
        return 9.7;
    }
}

public class BankInterest {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter Bank Name: ");
        if (!scanner.hasNextLine()) return;
        String input = scanner.nextLine().trim();
        
        String bankName = input;
        if (input.contains(",")) {
            bankName = input.split(",")[0].trim();
        }
        
        Bank bank = null;
        if (bankName.equalsIgnoreCase("SBI")) {
            bank = new SBI();
        } else if (bankName.equalsIgnoreCase("ICICI")) {
            bank = new ICICI();
        } else if (bankName.equalsIgnoreCase("AXIS")) {
            bank = new AXIS();
        } else {
            System.out.println("Invalid Bank: " + bankName);
            return;
        }
        
        System.out.println(bankName.toUpperCase() + " Rate of Interest: " + bank.getRateOfInterest() + "%");
    }
}
