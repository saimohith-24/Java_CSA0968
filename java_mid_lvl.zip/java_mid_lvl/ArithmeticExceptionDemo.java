public class ArithmeticExceptionDemo {
    public static void main(String[] args) {
        System.out.println("--- Simple Arithmetic Operations Demo ---");
        
        int num1 = 12;
        int num2 = 4;
        System.out.println("Addition of " + num1 + " + " + num2 + " = " + (num1 + num2));
        System.out.println("Subtraction of " + num1 + " - " + num2 + " = " + (num1 - num2));
        System.out.println("Multiplication of " + num1 + " * " + num2 + " = " + (num1 * num2));
        
        System.out.println("\n--- Performing Safe Division ---");
        divide(12, 4);

        System.out.println("\n--- Performing Unsafe Division (Division by Zero) ---");
        divide(12, 0);
    }

    public static void divide(int dividend, int divisor) {
        try {
            System.out.println("Attempting division: " + dividend + " / " + divisor);
            // This statement will throw ArithmeticException when divisor is 0
            int result = dividend / divisor;
            System.out.println("Result: " + result);
        } catch (ArithmeticException e) {
            System.out.println("Caught ArithmeticException: " + e.toString());
        }
    }
}
