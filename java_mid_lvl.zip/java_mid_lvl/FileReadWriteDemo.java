import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FileReadWriteDemo {
    public static void main(String[] args) {
        String filename = "cse_info.txt";
        String content = "Computer Science and Engineering";
        
        System.out.println("Writing to file: " + filename);
        // Write the string using FileWriter
        try (FileWriter writer = new FileWriter(filename)) {
            writer.write(content);
            System.out.println("Successfully wrote string: \"" + content + "\" to " + filename);
        } catch (IOException e) {
            System.out.println("An error occurred during file writing: " + e.getMessage());
        }

        System.out.println("\nReading from file: " + filename);
        // Read the string character by character using FileReader
        try (FileReader reader = new FileReader(filename)) {
            StringBuilder sb = new StringBuilder();
            int character;
            while ((character = reader.read()) != -1) {
                sb.append((char) character);
            }
            System.out.println("Successfully read content: \"" + sb.toString() + "\"");
        } catch (IOException e) {
            System.out.println("An error occurred during file reading: " + e.getMessage());
        }
    }
}
