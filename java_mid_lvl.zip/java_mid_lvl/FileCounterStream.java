import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.stream.Stream;

public class FileCounterStream {
    public static void main(String[] args) {
        String filepath = "cse_info.txt";
        
        // Ensure file exists for demonstration
        java.io.File file = new java.io.File(filepath);
        if (!file.exists()) {
            try {
                Files.write(Paths.get(filepath), Arrays.asList(
                    "Computer Science and Engineering",
                    "Welcome to Saveetha university",
                    "Stream I/O counts words, characters, and lines."
                ));
            } catch (IOException e) {
                System.out.println("Could not create test file: " + e.getMessage());
                return;
            }
        }

        System.out.println("Reading and counting contents of: " + filepath);
        try (Stream<String> lines = Files.lines(Paths.get(filepath))) {
            Stats stats = lines.map(line -> {
                long charCount = line.length();
                // Split line by whitespace to count words
                long wordCount = Stream.of(line.split("\\s+"))
                                       .filter(word -> !word.isEmpty())
                                       .count();
                return new Stats(1, wordCount, charCount);
            }).reduce(new Stats(0, 0, 0), Stats::add);

            System.out.println("\n--- File Count Results ---");
            System.out.println("Lines:      " + stats.lines);
            System.out.println("Words:      " + stats.words);
            System.out.println("Characters: " + stats.characters);
        } catch (IOException e) {
            System.out.println("Error reading the file: " + e.getMessage());
        }
    }

    static class Stats {
        final long lines;
        final long words;
        final long characters;

        Stats(long lines, long words, long characters) {
            this.lines = lines;
            this.words = words;
            this.characters = characters;
        }

        static Stats add(Stats a, Stats b) {
            return new Stats(a.lines + b.lines, a.words + b.words, a.characters + b.characters);
        }
    }
}
