import java.util.*;

public class NthLargest {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        try {
            System.out.print("List  : ");
            if (!scanner.hasNextLine()) return;
            String listInput = scanner.nextLine().trim();
            listInput = listInput.replace("{", "").replace("}", "");
            String[] tokens = listInput.split("[,\\s]+");
            List<Integer> list = new ArrayList<>();
            for (String token : tokens) {
                token = token.trim();
                if (!token.isEmpty()) {
                    list.add(Integer.parseInt(token));
                }
            }
            
            System.out.print("N = ");
            if (!scanner.hasNextLine()) return;
            String nInput = scanner.nextLine().trim();
            
            double nVal = Double.parseDouble(nInput);
            if (nVal != (int) nVal || nVal <= 0 || nVal > list.size()) {
                System.out.println("Invalid input");
                return;
            }
            int N = (int) nVal;

            // Sort the list in descending order
            list.sort(Collections.reverseOrder());
            int nthLargest = list.get(N - 1);
            
            System.out.println(getOrdinal(N) + " Largest number: " + nthLargest);

        } catch (Exception e) {
            System.out.println("Invalid input");
        }
    }

    private static String getOrdinal(int num) {
        if (num <= 0) return num + "";
        if (num % 100 >= 11 && num % 100 <= 13) {
            return num + "th";
        }
        switch (num % 10) {
            case 1: return num + "st";
            case 2: return num + "nd";
            case 3: return num + "rd";
            default: return num + "th";
        }
    }
}
