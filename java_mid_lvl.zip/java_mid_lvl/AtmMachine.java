import java.util.*;

public class AtmMachine {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int totalBalance = 0;
        Set<Integer> validDenominations = new HashSet<>(Arrays.asList(2000, 500, 200, 100));
        
        try {
            for (int i = 1; i <= 4; i++) {
                System.out.print("Enter the " + getOrdinal(i) + " Denomination: ");
                if (!scanner.hasNextInt()) {
                    System.out.println("Invalid input");
                    return;
                }
                int denom = scanner.nextInt();
                
                if (!validDenominations.contains(denom)) {
                    System.out.println("Invalid Denomination. Valid denominations are: 2000, 500, 200, 100");
                    return;
                }
                
                System.out.print("Enter the " + getOrdinal(i) + " Denomination number of notes: ");
                if (!scanner.hasNextInt()) {
                    System.out.println("Invalid input");
                    return;
                }
                int notes = scanner.nextInt();
                if (notes < 0) {
                    System.out.println("Number of notes cannot be negative");
                    return;
                }
                
                totalBalance += denom * notes;
            }
            
            System.out.println("Total Available Balance in ATM: " + totalBalance);
            
        } catch (Exception e) {
            System.out.println("Invalid input");
        }
    }

    private static String getOrdinal(int num) {
        switch (num) {
            case 1: return "1st";
            case 2: return "2nd";
            case 3: return "3rd";
            case 4: return "4th";
            default: return num + "th";
        }
    }
}
