import java.util.*;

public class MinMaxSumDiff {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        try {
            System.out.print("Array of elements = ");
            if (!scanner.hasNextLine()) return;
            String arrayInput = scanner.nextLine().trim();
            // Clean curly braces and split by comma or space
            arrayInput = arrayInput.replace("{", "").replace("}", "");
            String[] tokens = arrayInput.split("[,\\s]+");
            List<Integer> list = new ArrayList<>();
            for (String token : tokens) {
                token = token.trim();
                if (!token.isEmpty()) {
                    list.add(Integer.parseInt(token));
                }
            }
            
            System.out.print("M = ");
            if (!scanner.hasNextInt()) {
                System.out.println("Invalid input");
                return;
            }
            int M = scanner.nextInt();
            
            System.out.print("N = ");
            if (!scanner.hasNextInt()) {
                System.out.println("Invalid input");
                return;
            }
            int N = scanner.nextInt();

            int len = list.size();
            if (len == 0) {
                System.out.println("Array is empty");
                return;
            }

            if (M <= 0 || M > len) {
                System.out.println("M is out of range");
                return;
            }
            if (N <= 0 || N > len) {
                System.out.println("N is out of range");
                return;
            }

            Collections.sort(list);

            int mthMax = list.get(len - M);
            int nthMin = list.get(N - 1);

            int sum = mthMax + nthMin;
            int diff = mthMax - nthMin;

            System.out.println(getOrdinal(M) + "Maximum Number = " + mthMax);
            System.out.println(getOrdinal(N) + "Minimum Number = " + nthMin);
            System.out.println("Sum = " + sum);
            System.out.println("Difference = " + diff);

        } catch (Exception e) {
            System.out.println("Invalid input");
        }
    }

    private static String getOrdinal(int num) {
        if (num <= 0) return num + "";
        if (num % 100 >= 11 && num % 100 <= 13) {
            return num + "th";
        }
        switch (num % 10) {
            case 1: return num + "st";
            case 2: return num + "nd";
            case 3: return num + "rd";
            default: return num + "th";
        }
    }
}
