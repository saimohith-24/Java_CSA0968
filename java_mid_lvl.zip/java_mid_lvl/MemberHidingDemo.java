import java.util.Scanner;

class SuperClass {
    int value; // member variable

    // Parameterized constructor of the Super Class (accepts int type parameter)
    SuperClass(int value) {
        this.value = value;
    }
}

class SubClass extends SuperClass {
    int value; // This member hides the super class member of the same name

    // Sub Class constructor calling Super Class constructor using super()
    SubClass(int superValue, int subValue) {
        super(superValue); // calls SuperClass(int)
        this.value = subValue; // initializes its own 'value' variable
    }

    // Resolves hiding using 'super' keyword and displays values
    void display() {
        // super.value accesses the member in SuperClass
        // this.value or value accesses the member in SubClass
        System.out.println(super.value + ", " + this.value);
    }
}

public class MemberHidingDemo {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter two integer values (separated by comma or space): ");
        if (!scanner.hasNextLine()) return;
        String input = scanner.nextLine().trim();
        
        try {
            String[] parts = input.split("[,\\s]+");
            if (parts.length < 2) {
                System.out.println("Invalid input. Please enter two integers.");
                return;
            }
            
            // Validate inputs
            double val1 = Double.parseDouble(parts[0].trim());
            double val2 = Double.parseDouble(parts[1].trim());
            
            // Must be integers
            if (val1 != (int) val1 || val2 != (int) val2) {
                System.out.println("Invalid input. Only integers are allowed.");
                return;
            }
            
            int intVal1 = (int) val1;
            int intVal2 = (int) val2;
            
            SubClass sub = new SubClass(intVal1, intVal2);
            sub.display();
            
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. Only integers are allowed.");
        }
    }
}
