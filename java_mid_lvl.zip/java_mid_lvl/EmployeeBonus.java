import java.util.Scanner;

public class EmployeeBonus {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        try {
            System.out.print("Enter the grade of the employee: ");
            if (!scanner.hasNext()) {
                System.out.println("Invalid input");
                return;
            }
            String gradeInput = scanner.next().trim();
            if (gradeInput.length() != 1) {
                System.out.println("Invalid input");
                return;
            }
            char grade = Character.toUpperCase(gradeInput.charAt(0));
            if (!Character.isLetter(grade)) {
                System.out.println("Invalid input");
                return;
            }

            System.out.print("Enter the employee salary: ");
            if (!scanner.hasNextDouble()) {
                System.out.println("Invalid input");
                return;
            }
            double salary = scanner.nextDouble();
            if (salary < 0) {
                System.out.println("Salary cannot be negative");
                return;
            }

            double bonusPercent = 0.0;
            if (grade == 'A') {
                bonusPercent = 0.05;
            } else if (grade == 'B') {
                bonusPercent = 0.10;
            } else {
                bonusPercent = 0.0;
            }

            if (salary < 10000) {
                bonusPercent += 0.02;
            }

            double bonus = salary * bonusPercent;
            double total = salary + bonus;

            String salaryStr = (salary == (long) salary) ? String.valueOf((long) salary) : String.valueOf(salary);
            System.out.println("Salary=" + salaryStr);
            System.out.println("Bonus=" + bonus);
            System.out.println("Total to be paid:" + total);

        } catch (Exception e) {
            System.out.println("Invalid input");
        }
    }
}
