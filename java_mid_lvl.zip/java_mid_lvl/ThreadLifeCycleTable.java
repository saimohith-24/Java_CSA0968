import java.util.Scanner;

class TableThread extends Thread {
    private final int number;

    TableThread(int number) {
        this.number = number;
    }

    @Override
    public void run() {
        System.out.println(Thread.currentThread().getName() + " is in RUNNABLE state.");
        for (int i = 1; i <= 10; i++) {
            System.out.println(number + " X " + i + " = " + (number * i));
            try {
                // Sleep causes the thread to enter TIMED_WAITING state
                Thread.sleep(100);
            } catch (InterruptedException e) {
                System.out.println(Thread.currentThread().getName() + " was interrupted.");
            }
        }
    }
}

public class ThreadLifeCycleTable {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter two integers (separated by comma or space): ");
        if (!scanner.hasNextLine()) return;
        String input = scanner.nextLine().trim();

        try {
            String[] parts = input.split("[,\\s]+");
            if (parts.length < 2) {
                System.out.println("Invalid input. Please enter two integers.");
                return;
            }

            double val1 = Double.parseDouble(parts[0].trim());
            double val2 = Double.parseDouble(parts[1].trim());

            if (val1 != (int) val1 || val2 != (int) val2) {
                System.out.println("Invalid input. Only integers are allowed.");
                return;
            }

            int n1 = (int) val1;
            int n2 = (int) val2;

            TableThread thread1 = new TableThread(n1);
            TableThread thread2 = new TableThread(n2);

            thread1.setName("Thread-Table-" + n1);
            thread2.setName("Thread-Table-" + n2);

            // 1. NEW State
            System.out.println(thread1.getName() + " state before start: " + thread1.getState());
            System.out.println(thread2.getName() + " state before start: " + thread2.getState());

            thread1.start();
            thread2.start();

            // 2. TIMED_WAITING or RUNNABLE state during execution
            try {
                Thread.sleep(50);
                System.out.println(thread1.getName() + " state during execution: " + thread1.getState());
                System.out.println(thread2.getName() + " state during execution: " + thread2.getState());
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            try {
                thread1.join();
                thread2.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            // 3. TERMINATED State
            System.out.println(thread1.getName() + " state after completion: " + thread1.getState());
            System.out.println(thread2.getName() + " state after completion: " + thread2.getState());

        } catch (NumberFormatException e) {
            System.out.println("Invalid input. Only integers are allowed.");
        }
    }
}
