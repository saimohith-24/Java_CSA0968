import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class PerfectNumbers {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("N = ");
        if (!scanner.hasNextLine()) return;
        String input = scanner.nextLine().trim();
        
        try {
            // Check if it is a valid integer
            double val = Double.parseDouble(input);
            if (val != (int) val || val <= 0) {
                System.out.println("Invalid input. N must be a positive integer.");
                return;
            }
            int N = (int) val;
            
            List<Long> perfectNumbers = new ArrayList<>();
            long p = 2;
            // Generate perfect numbers using Euclid-Euler theorem: 2^(p-1) * (2^p - 1)
            while (perfectNumbers.size() < N) {
                if (isPrime(p)) {
                    long mersenne = (1L << p) - 1;
                    if (isPrime(mersenne)) {
                        long perfect = (1L << (p - 1)) * mersenne;
                        perfectNumbers.add(perfect);
                    }
                }
                p++;
            }
            
            System.out.print("First " + N + " perfect numbers are: ");
            for (int i = 0; i < perfectNumbers.size(); i++) {
                System.out.print(perfectNumbers.get(i));
                if (i < perfectNumbers.size() - 1) {
                    System.out.print(" , ");
                }
            }
            System.out.println();
            
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. N must be a positive integer.");
        }
    }

    private static boolean isPrime(long n) {
        if (n <= 1) return false;
        if (n == 2) return true;
        if (n % 2 == 0) return false;
        for (long i = 3; i * i <= n; i += 2) {
            if (n % i == 0) return false;
        }
        return true;
    }
}
