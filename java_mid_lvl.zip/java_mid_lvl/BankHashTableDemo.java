import java.util.Hashtable;

public class BankHashTableDemo {
    public static void main(String[] args) {
        System.out.println("--- Bank Account HashTable Operations ---");
        
        // Creating Hashtable to store Account Number (Key) and Customer Name (Value)
        Hashtable<String, String> bankTable = new Hashtable<>();

        // Operation 1: Add 3 records
        System.out.println("1. Adding 3 account records to the HashTable...");
        bankTable.put("ACC78291", "Saimohith");
        bankTable.put("ACC56431", "Alex Pandian");
        bankTable.put("ACC99824", "Priya Sharma");
        
        System.out.println("HashTable Content: " + bankTable);

        // Operation 2: Display the size of HashTable
        System.out.println("\n2. Displaying the size of HashTable...");
        System.out.println("Current Size: " + bankTable.size());

        // Operation 3: Clear the HashTable
        System.out.println("\n3. Clearing the HashTable...");
        bankTable.clear();
        
        System.out.println("Size after clearing: " + bankTable.size());
        System.out.println("Is HashTable empty? " + bankTable.isEmpty());
    }
}
