public class PowerCalculator {
    public static void main(String[] args) {
        System.out.println("--- Power Calculator (pow(x, n)) ---");
        
        // Test case 1
        double x1 = 2.0;
        int n1 = 10;
        System.out.printf("Input:  x = %.5f, n = %d\n", x1, n1);
        System.out.printf("Output: %.5f\n\n", myPow(x1, n1));

        // Test case 2: Negative exponent
        double x2 = 2.0;
        int n2 = -2;
        System.out.printf("Input:  x = %.5f, n = %d\n", x2, n2);
        System.out.printf("Output: %.5f\n\n", myPow(x2, n2));

        // Test case 3: Fractional base
        double x3 = 8.84372;
        int n3 = 6;
        System.out.printf("Input:  x = %.5f, n = %d\n", x3, n3);
        System.out.printf("Output: %.5f\n", myPow(x3, n3));
    }

    // Binary Exponentiation (O(log n) complexity)
    public static double myPow(double x, int n) {
        long N = n;
        if (N < 0) {
            x = 1 / x;
            N = -N;
        }
        
        double result = 1.0;
        double currentProduct = x;
        
        for (long i = N; i > 0; i /= 2) {
            if (i % 2 == 1) {
                result = result * currentProduct;
            }
            currentProduct = currentProduct * currentProduct;
        }
        
        return result;
    }
}
