import java.util.Scanner;

public class CharCounter {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter * to exit...");
        
        int lowerCount = 0;
        int upperCount = 0;
        int digitCount = 0;
        
        boolean exited = false;
        
        while (scanner.hasNextLine() && !exited) {
            String line = scanner.nextLine();
            if (line.trim().isEmpty()) {
                break;
            }
            String[] tokens = line.split("[,\\s]+");
            for (String token : tokens) {
                token = token.trim();
                if (token.isEmpty()) continue;
                
                for (int i = 0; i < token.length(); i++) {
                    char c = token.charAt(i);
                    if (c == '*') {
                        exited = true;
                        break;
                    }
                    if (Character.isLowerCase(c)) {
                        lowerCount++;
                    } else if (Character.isUpperCase(c)) {
                        upperCount++;
                    } else if (Character.isDigit(c)) {
                        digitCount++;
                    }
                }
                if (exited) break;
            }
        }
        
        System.out.println("Total count of lower case:" + lowerCount);
        System.out.println("Total count of upper case:" + upperCount);
        System.out.println("Total count of numbers =" + digitCount);
    }
}
