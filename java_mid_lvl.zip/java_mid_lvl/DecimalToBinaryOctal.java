import java.util.Scanner;

public class DecimalToBinaryOctal {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Decimal Number: ");
        if (!scanner.hasNextLine()) return;
        String input = scanner.nextLine().trim();
        try {
            double val = Double.parseDouble(input);
            if (val < 0) {
                System.out.println("Negative numbers are not supported.");
                return;
            }
            
            if (val == (long) val) {
                long intVal = (long) val;
                System.out.println("Binary Number = " + Long.toBinaryString(intVal));
                System.out.println("Octal = " + Long.toOctalString(intVal));
            } else {
                long intVal = (long) val;
                double fracVal = val - intVal;
                
                String binInt = Long.toBinaryString(intVal);
                String binFrac = getFractionalBinary(fracVal, 6);
                
                String octInt = Long.toOctalString(intVal);
                String octFrac = getFractionalOctal(fracVal, 6);
                
                System.out.println("Binary Number = " + binInt + "." + binFrac);
                System.out.println("Octal = " + octInt + "." + octFrac);
            }
        } catch (NumberFormatException e) {
            System.out.println("Invalid input");
        }
    }

    private static String getFractionalBinary(double frac, int limit) {
        StringBuilder sb = new StringBuilder();
        double temp = frac;
        for (int i = 0; i < limit; i++) {
            temp *= 2;
            int bit = (int) temp;
            sb.append(bit);
            temp -= bit;
            if (temp == 0) break;
        }
        return sb.toString();
    }

    private static String getFractionalOctal(double frac, int limit) {
        StringBuilder sb = new StringBuilder();
        double temp = frac;
        for (int i = 0; i < limit; i++) {
            temp *= 8;
            int digit = (int) temp;
            sb.append(digit);
            temp -= digit;
            if (temp == 0) break;
        }
        return sb.toString();
    }
}
