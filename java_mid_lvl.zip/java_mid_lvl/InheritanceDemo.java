public class InheritanceDemo {
    public static void main(String[] args) {
        System.out.println("--- Inheritance & Method Invocation Demo ---");

        // 1 - method of parent class by object of parent class
        Parent parentObj = new Parent();
        System.out.print("1. Calling parent class method by parent class object: ");
        parentObj.printParentMessage();

        // 2 - method of child class by object of child class
        Child childObj = new Child();
        System.out.print("2. Calling child class method by child class object: ");
        childObj.printChildMessage();

        // 3 - method of parent class by object of child class (inherited method)
        System.out.print("3. Calling parent class method by child class object: ");
        childObj.printParentMessage();
    }

    static class Parent {
        public void printParentMessage() {
            System.out.println("This is parent class");
        }
    }

    static class Child extends Parent {
        public void printChildMessage() {
            System.out.println("This is child class");
        }
    }
}
