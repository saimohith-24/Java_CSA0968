import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.ListIterator;

public class ListIteratorDemo {
    public static void main(String[] args) {
        System.out.println("--- ListIterator Demo ---");
        
        // Initialize list with given elements
        List<String> list = new ArrayList<>(Arrays.asList("C", "A", "E", "B", "D", "F"));
        System.out.println("Original Elements: " + list);

        // Get ListIterator
        ListIterator<String> iterator = list.listIterator();

        // 1. Traverse forward and append '+' to each element
        while (iterator.hasNext()) {
            String element = iterator.next();
            // Use set() to modify the current element in the list
            iterator.set(element + "+");
        }
        System.out.println("Elements after appending '+': " + list);

        // 2. Traverse backward (reverse order) and print them
        System.out.print("Reverse Order Traversal: ");
        while (iterator.hasPrevious()) {
            System.out.print(iterator.previous() + " ");
        }
        System.out.println();
    }
}
