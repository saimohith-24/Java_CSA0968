import java.util.Scanner;

public class SpecialCharCounter {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Given statement: ");
        if (!scanner.hasNextLine()) return;
        String line = scanner.nextLine();
        
        int specialCount = 0;
        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);
            // Ignore letters, digits, spaces, and basic punctuation like commas and periods
            if (!Character.isLetterOrDigit(c) && !Character.isWhitespace(c) && c != ',' && c != '.') {
                specialCount++;
            }
        }
        System.out.println("Number of special Characters: " + specialCount);
    }
}
