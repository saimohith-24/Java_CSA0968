import java.util.Scanner;

public class StudentGrade {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        try {
            double[] marks = new double[4];
            String[] subjects = {"python", "c programming", "Mathematics", "Physics"};
            
            for (int i = 0; i < 4; i++) {
                System.out.print("Enter the marks in " + subjects[i] + ": ");
                if (!scanner.hasNextDouble()) {
                    System.out.println("Invalid input");
                    return;
                }
                marks[i] = scanner.nextDouble();
                if (marks[i] < 0 || marks[i] > 100) {
                    System.out.println("Invalid marks. Marks should be between 0 and 100.");
                    return;
                }
            }

            double total = 0;
            for (double mark : marks) {
                total += mark;
            }
            double aggregate = total / 4.0;

            String totalStr = (total == (int) total) ? String.valueOf((int) total) : String.valueOf(total);
            String aggStr = (aggregate == (int) aggregate) ? String.valueOf((int) aggregate) : String.valueOf(aggregate);

            System.out.println("Total= " + totalStr);
            System.out.println("Aggregate = " + aggStr);

            if (aggregate > 75) {
                System.out.println("DISTINCTION");
            } else if (aggregate >= 60) {
                System.out.println("FIRST DIVISION");
            } else if (aggregate >= 50) {
                System.out.println("SECOND DIVISION");
            } else if (aggregate >= 40) {
                System.out.println("THIRD DIVISION");
            } else {
                System.out.println("FAIL");
            }

        } catch (Exception e) {
            System.out.println("Invalid input");
        }
    }
}
