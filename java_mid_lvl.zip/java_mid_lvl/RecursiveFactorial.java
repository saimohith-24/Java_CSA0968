import java.util.Scanner;

public class RecursiveFactorial {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the value of n: ");
        if (!scanner.hasNextLine()) return;
        String input = scanner.nextLine().trim();
        
        try {
            double val = Double.parseDouble(input);
            if (val != (int) val || val < 0) {
                System.out.println("Invalid input. n must be a non-negative integer.");
                return;
            }
            int n = (int) val;
            long fact = factorial(n);
            System.out.println("The factorial of " + n + " is: " + fact);
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. n must be a non-negative integer.");
        }
    }

    private static long factorial(int n) {
        if (n <= 1) return 1;
        return n * factorial(n - 1);
    }
}
