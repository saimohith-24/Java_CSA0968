public class MissingNumberFinder {
    public static void main(String[] args) {
        int n = 8;
        int[] a = {1, 4, 5, 3, 7, 8, 6};

        System.out.println("--- Missing Number Finder ---");
        System.out.println("Expected Range: 1 to " + n);
        System.out.print("Array 'a' content: {");
        for (int i = 0; i < a.length; i++) {
            System.out.print(a[i] + (i < a.length - 1 ? ", " : ""));
        }
        System.out.println("}");

        int missing = findMissingNumber(a, n);
        System.out.println("Output: The missing number is " + missing);
    }

    public static int findMissingNumber(int[] array, int n) {
        // Mathematical formula for sum of 1 to n: n * (n + 1) / 2
        int expectedSum = n * (n + 1) / 2;
        int actualSum = 0;
        for (int num : array) {
            actualSum += num;
        }
        return expectedSum - actualSum;
    }
}
