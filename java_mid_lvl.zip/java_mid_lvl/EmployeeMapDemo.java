import java.util.HashMap;
import java.util.Map;

public class EmployeeMapDemo {
    public static void main(String[] args) {
        System.out.println("--- Employee Records Map Operations ---");
        
        // Declare a Map for Employee Records: Key = ID (Integer), Value = Name & Dept (String)
        Map<Integer, String> employeeMap = new HashMap<>();

        // 1. Check if Map is empty initially
        System.out.println("Is the employee map empty initially? " + employeeMap.isEmpty());

        // 2. Add objects (Employee records)
        System.out.println("\nAdding employee objects to the map...");
        employeeMap.put(1001, "Aravind - Software Architect");
        employeeMap.put(1002, "Catherine - UI/UX Designer");
        employeeMap.put(1003, "Dinesh - QA Lead");
        
        System.out.println("Current Employee Map: " + employeeMap);
        System.out.println("Is the employee map empty now? " + employeeMap.isEmpty());

        // 3. Remove specified object
        int idToRemove = 1002;
        System.out.println("\nRemoving employee with ID " + idToRemove + "...");
        String removedValue = employeeMap.remove(idToRemove);
        System.out.println("Removed: " + removedValue);
        System.out.println("Employee Map after removal: " + employeeMap);

        // 4. Clear the map
        System.out.println("\nClearing all records in the map...");
        employeeMap.clear();
        System.out.println("Is the employee map empty after clearing? " + employeeMap.isEmpty());
    }
}
