import java.util.Scanner;

public class ArraySumWithException {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        try {
            System.out.print("Enter N: ");
            if (!scanner.hasNextLine()) return;
            String nInput = scanner.nextLine().trim();
            
            double nVal = Double.parseDouble(nInput);
            if (nVal != (int) nVal || nVal < 0) {
                System.out.println("Invalid input. N must be a non-negative integer.");
                return;
            }
            int N = (int) nVal;
            
            int[] arr = new int[N];
            System.out.print("Enter " + N + " numbers: ");
            if (!scanner.hasNextLine()) return;
            String elementsInput = scanner.nextLine().trim();
            String[] tokens = elementsInput.split("[,\\s]+");
            
            for (int i = 0; i < N && i < tokens.length; i++) {
                arr[i] = Integer.parseInt(tokens[i].trim());
            }

            int sum = 0;
            try {
                // Iterating up to N (inclusive) to intentionally throw ArrayIndexOutOfBoundsException
                for (int i = 0; i <= N; i++) {
                    sum += arr[i];
                }
            } catch (ArrayIndexOutOfBoundsException e) {
                // Output the sum when exception is caught
                System.out.println(sum);
            }
            
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. Only integers are allowed.");
        } catch (NegativeArraySizeException e) {
            System.out.println("Invalid array size.");
        } catch (Exception e) {
            System.out.println("Invalid input.");
        }
    }
}
