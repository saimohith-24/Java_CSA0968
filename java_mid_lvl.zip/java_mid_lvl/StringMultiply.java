public class StringMultiply {
    public static void main(String[] args) {
        String num1 = "123";
        String num2 = "456";
        System.out.println("--- String Multiplication Demo ---");
        System.out.println("Number 1: \"" + num1 + "\"");
        System.out.println("Number 2: \"" + num2 + "\"");
        
        String result = multiply(num1, num2);
        System.out.println("Product:  \"" + result + "\"");
        
        // Let's test with larger numbers
        String large1 = "999999999999999999";
        String large2 = "999999999999999999";
        System.out.println("\nNumber 1: \"" + large1 + "\"");
        System.out.println("Number 2: \"" + large2 + "\"");
        System.out.println("Product:  \"" + multiply(large1, large2) + "\"");
    }

    public static String multiply(String num1, String num2) {
        if (num1 == null || num2 == null) {
            return "0";
        }
        if (num1.equals("0") || num2.equals("0")) {
            return "0";
        }

        int len1 = num1.length();
        int len2 = num2.length();
        int[] result = new int[len1 + len2];

        // Perform digit-by-digit multiplication starting from the end
        for (int i = len1 - 1; i >= 0; i--) {
            for (int j = len2 - 1; j >= 0; j--) {
                int digit1 = num1.charAt(i) - '0';
                int digit2 = num2.charAt(j) - '0';
                int product = digit1 * digit2;

                // Indices in the result array
                int p1 = i + j;
                int p2 = i + j + 1;

                int sum = product + result[p2];
                result[p2] = sum % 10;
                result[p1] += sum / 10;
            }
        }

        // Convert the result array into a string
        StringBuilder sb = new StringBuilder();
        for (int digit : result) {
            if (!(sb.length() == 0 && digit == 0)) {
                sb.append(digit);
            }
        }

        return sb.length() == 0 ? "0" : sb.toString();
    }
}
