import java.util.*;

public class RemoveDuplicates {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        try {
            System.out.print("Enter the number of elements in array: ");
            if (!scanner.hasNextInt()) {
                System.out.println("Invalid input");
                return;
            }
            int n = scanner.nextInt();
            if (n < 0) {
                System.out.println("Number of elements cannot be negative");
                return;
            }
            
            Set<Integer> uniqueSet = new LinkedHashSet<>();
            for (int i = 1; i <= n; i++) {
                System.out.print("Enter element" + i + ": ");
                if (!scanner.hasNextInt()) {
                    System.out.println("Invalid input");
                    return;
                }
                uniqueSet.add(scanner.nextInt());
            }
            
            System.out.println("Non-duplicate items:");
            System.out.println(uniqueSet.toString());
            
        } catch (Exception e) {
            System.out.println("Invalid input");
        }
    }
}
