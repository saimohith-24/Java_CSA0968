import java.util.Scanner;

public class StringOperationsDemo {
    public static void main(String[] args) {
        String baseString = "Welcome to Saveetha university";
        System.out.println("--- String Operations Demo ---");
        System.out.println("Base String: \"" + baseString + "\"");

        // Operation 1: Find the length
        int length = baseString.length();
        System.out.println("Length of String: " + length);

        // Operation 2: Uppercase Conversion
        String upper = baseString.toUpperCase();
        System.out.println("Uppercase Conversion: \"" + upper + "\"");

        // Operation 3: Replace any word (Default demonstration: Saveetha -> Saveetha Engineering)
        String replacedDefault = baseString.replace("Saveetha", "Saveetha Engineering");
        System.out.println("Default Replacement ('Saveetha' -> 'Saveetha Engineering'): \"" + replacedDefault + "\"");

        // Custom user input replacement
        Scanner scanner = new Scanner(System.in);
        System.out.println("\n--- Custom Replacement Option ---");
        System.out.print("Enter word in the base string to replace: ");
        if (scanner.hasNextLine()) {
            String wordToReplace = scanner.nextLine().trim();
            System.out.print("Enter the replacement word: ");
            if (scanner.hasNextLine()) {
                String replacementWord = scanner.nextLine().trim();
                if (baseString.contains(wordToReplace)) {
                    String customReplaced = baseString.replace(wordToReplace, replacementWord);
                    System.out.println("Custom Replaced String: \"" + customReplaced + "\"");
                } else {
                    System.out.println("Warning: The word \"" + wordToReplace + "\" was not found in the original string.");
                }
            }
        }
        scanner.close();
    }
}
