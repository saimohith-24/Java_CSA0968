import java.util.Scanner;

public class PrimeRunnableChecker {
    public static void main(String[] args) {
        String[] testInputs = {"5", "15", "4", "-10", "0", "EIGHT SEVEN", "11.48"};
        
        System.out.println("--- Running Predefined Test Cases ---");
        for (String input : testInputs) {
            System.out.println("Testing input: \"" + input + "\"");
            processInput(input);
            System.out.println();
        }
        
        System.out.println("--- Interactive Input (Enter 'exit' to quit) ---");
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.print("Enter a number to check: ");
            if (!scanner.hasNextLine()) break;
            String input = scanner.nextLine().trim();
            if (input.equalsIgnoreCase("exit")) {
                break;
            }
            processInput(input);
            System.out.println();
        }
        scanner.close();
    }

    private static void processInput(String input) {
        try {
            // Check if input is a float
            if (input.contains(".")) {
                throw new NumberFormatException("Floating point numbers are not allowed for primality test.");
            }
            
            int number = Integer.parseInt(input);
            PrimeChecker checker = new PrimeChecker(number);
            Thread thread = new Thread(checker);
            thread.start();
            thread.join(); // Wait for the check to complete
        } catch (NumberFormatException e) {
            System.out.println("Output: Invalid Input - \"" + input + "\" is not a valid integer.");
        } catch (InterruptedException e) {
            System.out.println("Thread execution was interrupted.");
        }
    }

    static class PrimeChecker implements Runnable {
        private final int number;

        public PrimeChecker(int number) {
            this.number = number;
        }

        @Override
        public void run() {
            if (isPrime(number)) {
                System.out.println("Output: " + number + " is Prime");
            } else {
                System.out.println("Output: " + number + " is not Prime");
            }
        }

        private boolean isPrime(int n) {
            if (n <= 1) {
                return false;
            }
            for (int i = 2; i <= Math.sqrt(n); i++) {
                if (n % i == 0) {
                    return false;
                }
            }
            return true;
        }
    }
}
