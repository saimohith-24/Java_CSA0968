import java.util.Scanner;

public class BinaryToDecimalOctal {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Given Number: ");
        if (!scanner.hasNextLine()) return;
        String input = scanner.nextLine().trim();
        
        if (!isValidBinary(input)) {
            System.out.println("Invalid input. Not a valid binary number.");
            return;
        }
        
        String intPart;
        String fracPart = "";
        if (input.contains(".")) {
            int dotIdx = input.indexOf('.');
            intPart = input.substring(0, dotIdx);
            fracPart = input.substring(dotIdx + 1);
        } else {
            intPart = input;
        }
        
        if (intPart.isEmpty()) {
            intPart = "0";
        }
        
        try {
            long decInt = Long.parseLong(intPart, 2);
            double decFrac = 0.0;
            for (int i = 0; i < fracPart.length(); i++) {
                if (fracPart.charAt(i) == '1') {
                    decFrac += Math.pow(2, -(i + 1));
                }
            }
            
            double totalDec = decInt + decFrac;
            String decStr = (decFrac == 0.0) ? String.valueOf(decInt) : String.valueOf(totalDec);
            
            String octInt = Long.toOctalString(decInt);
            String octStr;
            if (fracPart.isEmpty()) {
                octStr = octInt;
            } else {
                StringBuilder fracBin = new StringBuilder(fracPart);
                while (fracBin.length() % 3 != 0) {
                    fracBin.append('0');
                }
                StringBuilder octFrac = new StringBuilder();
                for (int i = 0; i < fracBin.length(); i += 3) {
                    String grp = fracBin.substring(i, i + 3);
                    int val = Integer.parseInt(grp, 2);
                    octFrac.append(val);
                }
                octStr = octInt + "." + octFrac.toString();
            }
            
            System.out.println("Decimal Number: " + decStr);
            System.out.println("Octal: " + octStr);
            
        } catch (Exception e) {
            System.out.println("Invalid input");
        }
    }

    private static boolean isValidBinary(String s) {
        if (s.isEmpty()) return false;
        int dotCount = 0;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '.') {
                dotCount++;
                if (dotCount > 1) return false;
            } else if (c != '0' && c != '1') {
                return false;
            }
        }
        return true;
    }
}
