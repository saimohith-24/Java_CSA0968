import java.util.Scanner;

public class PalindromeChecker {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        try {
            System.out.print("Case = ");
            if (!scanner.hasNextInt()) {
                System.out.println("Invalid choice");
                return;
            }
            int choice = scanner.nextInt();
            scanner.nextLine(); // consume newline
            
            if (choice == 1) {
                System.out.print("String = ");
                if (!scanner.hasNextLine()) return;
                String str = scanner.nextLine().trim();
                if (isPalindrome(str)) {
                    System.out.println("Palindrome");
                } else {
                    System.out.println("Not a Palindrome");
                }
            } else if (choice == 2) {
                System.out.print("Number = ");
                if (!scanner.hasNextLine()) return;
                String numStr = scanner.nextLine().trim();
                // Check if it is a valid number (integer or decimal)
                try {
                    Double.parseDouble(numStr);
                } catch (NumberFormatException e) {
                    System.out.println("Invalid number");
                    return;
                }
                if (isPalindrome(numStr)) {
                    System.out.println("Palindrome");
                } else {
                    System.out.println("Not a Palindrome");
                }
            } else {
                System.out.println("Invalid choice");
            }
        } catch (Exception e) {
            System.out.println("Invalid input");
        }
    }

    private static boolean isPalindrome(String s) {
        String cleaned = s.toLowerCase();
        int left = 0;
        int right = cleaned.length() - 1;
        while (left < right) {
            if (cleaned.charAt(left) != cleaned.charAt(right)) {
                return false;
            }
            left++;
            right--;
        }
        return true;
    }
}
