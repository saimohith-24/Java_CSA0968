public class BoxVolumeDemo {
    public static void main(String[] args) {
        System.out.println("Creating a Box using the default constructor...");
        Box box = new Box();
        
        System.out.println("Dimensions of the Box: ");
        System.out.println("Width:  " + box.getWidth());
        System.out.println("Height: " + box.getHeight());
        System.out.println("Depth:  " + box.getDepth());
        
        System.out.println("Volume of the Box: " + box.calculateVolume());
    }

    static class Box {
        private double width;
        private double height;
        private double depth;

        // Default constructor method
        public Box() {
            // Assign default dimensions
            this.width = 10.0;
            this.height = 5.0;
            this.depth = 4.0;
        }

        public double getWidth() {
            return width;
        }

        public double getHeight() {
            return height;
        }

        public double getDepth() {
            return depth;
        }

        public double calculateVolume() {
            return width * height * depth;
        }
    }
}
