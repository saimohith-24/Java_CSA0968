public class MultiCatchDemo {
    public static void main(String[] args) {
        System.out.println("--- Multi-Catch Exception Handling Demo ---");
        
        for (int i = 0; i < 3; i++) {
            try {
                if (i == 0) {
                    System.out.println("Case 1: Triggering ArithmeticException (Division by Zero)...");
                    int result = 10 / 0;
                } else if (i == 1) {
                    System.out.println("Case 2: Triggering ArrayIndexOutOfBoundsException...");
                    int[] arr = new int[3];
                    int value = arr[5];
                } else if (i == 2) {
                    System.out.println("Case 3: Triggering NullPointerException...");
                    String str = null;
                    int length = str.length();
                }
            } catch (ArithmeticException | ArrayIndexOutOfBoundsException | NullPointerException e) {
                System.out.println("Caught exception in Multi-Catch block!");
                System.out.println("Exception Type: " + e.getClass().getName());
                System.out.println("Message: " + e.toString());
                System.out.println();
            }
        }
        System.out.println("Execution finished cleanly after handling exceptions.");
    }
}
