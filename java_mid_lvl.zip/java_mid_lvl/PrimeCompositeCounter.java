import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class PrimeCompositeCounter {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the numbers:");
        
        List<String> tokens = new ArrayList<>();
        // Read lines until EOF or empty input
        while (scanner.hasNextLine()) {
            String line = scanner.nextLine().trim();
            if (line.isEmpty()) {
                break;
            }
            // Split by comma or space
            String[] parts = line.split("[,\\s]+");
            for (String part : parts) {
                if (!part.trim().isEmpty()) {
                    tokens.add(part.trim());
                }
            }
        }

        int primeCount = 0;
        int compositeCount = 0;

        for (String token : tokens) {
            try {
                double val = Double.parseDouble(token);
                if (val == (int) val) {
                    int num = (int) val;
                    if (num > 1) {
                        if (isPrime(num)) {
                            primeCount++;
                        } else {
                            compositeCount++;
                        }
                    }
                }
            } catch (NumberFormatException e) {
                // Ignore text tokens like TEN, FIFTY as per test cases
            }
        }
        System.out.println("Composite number:" + compositeCount);
        System.out.println("Prime number:" + primeCount);
    }

    private static boolean isPrime(int n) {
        if (n <= 1) return false;
        for (int i = 2; i <= Math.sqrt(n); i++) {
            if (n % i == 0) return false;
        }
        return true;
    }
}
