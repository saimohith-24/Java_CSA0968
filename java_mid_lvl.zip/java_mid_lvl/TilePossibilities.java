public class TilePossibilities {
    public static void main(String[] args) {
        System.out.println("--- Letter Tile Possibilities ---");
        
        // Test case 1
        String tiles1 = "AAB";
        System.out.println("Input tiles: \"" + tiles1 + "\"");
        System.out.println("Output: " + numTilePossibilities(tiles1));
        System.out.println("Explanation: The 8 sequences are A, B, AA, AB, BA, AAB, ABA, BAA.\n");

        // Test case 2
        String tiles2 = "AAABBC";
        System.out.println("Input tiles: \"" + tiles2 + "\"");
        System.out.println("Output: " + numTilePossibilities(tiles2));
    }

    public static int numTilePossibilities(String tiles) {
        if (tiles == null || tiles.length() == 0) {
            return 0;
        }
        
        // Count frequencies of each letter
        int[] frequencyMap = new int[26];
        for (char c : tiles.toCharArray()) {
            frequencyMap[c - 'A']++;
        }
        
        return countSequences(frequencyMap);
    }

    private static int countSequences(int[] frequencyMap) {
        int sum = 0;
        for (int i = 0; i < 26; i++) {
            if (frequencyMap[i] == 0) {
                continue;
            }
            
            // Choose the character
            sum++;
            frequencyMap[i]--;
            
            // Recurse to build longer sequences
            sum += countSequences(frequencyMap);
            
            // Backtrack
            frequencyMap[i]++;
        }
        return sum;
    }
}
