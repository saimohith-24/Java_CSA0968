import java.util.*;

public class PositiveNegativeAverage {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter -1 to exit...");
        
        double posSum = 0;
        int posCount = 0;
        double negSum = 0;
        int negCount = 0;
        
        boolean exited = false;
        
        while (scanner.hasNextLine() && !exited) {
            String line = scanner.nextLine();
            if (line.trim().isEmpty()) {
                break;
            }
            String[] tokens = line.split("[,\\s]+");
            for (String token : tokens) {
                token = token.trim();
                if (token.isEmpty()) continue;
                try {
                    double num = Double.parseDouble(token);
                    if (num == -1) {
                        exited = true;
                        break;
                    }
                    if (num > 0) {
                        posSum += num;
                        posCount++;
                    } else if (num < 0) {
                        negSum += num;
                        negCount++;
                    }
                } catch (NumberFormatException e) {
                    // Skip invalid tokens
                }
            }
        }
        
        if (negCount > 0) {
            double avg = negSum / negCount;
            System.out.println("The average of negative numbers is: " + formatAvg(avg));
        } else {
            System.out.println("The average of negative numbers is: 0.0");
        }
        
        if (posCount > 0) {
            double avg = posSum / posCount;
            System.out.println("The average of positive numbers is : " + formatAvg(avg));
        } else {
            System.out.println("The average of positive numbers is : 0.0");
        }
    }

    private static String formatAvg(double val) {
        if (val == (long) val) {
            return (long) val + ".0";
        }
        return String.format(Locale.US, "%.8f", val);
    }
}
