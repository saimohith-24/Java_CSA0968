package AT3;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class TicketBookingSystem extends JFrame
        implements ActionListener {

    JComboBox<String> seatBox;

    JButton bookBtn;
    JButton cancelBtn;

    JTextArea statusArea;

    public TicketBookingSystem() {

        setTitle("Ticket Booking System");

        setSize(600, 400);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setLocationRelativeTo(null);

        setLayout(new BorderLayout());

        JPanel topPanel = new JPanel();

        topPanel.add(new JLabel("Select Seat"));

        String seats[] = {
                "A1", "A2", "A3",
                "B1", "B2", "B3",
                "C1", "C2", "C3"
        };

        seatBox = new JComboBox<>(seats);

        topPanel.add(seatBox);

        add(topPanel, BorderLayout.NORTH);

        JPanel btnPanel = new JPanel();

        bookBtn = new JButton("Book Ticket");
        cancelBtn = new JButton("Cancel Ticket");

        bookBtn.addActionListener(this);
        cancelBtn.addActionListener(this);

        btnPanel.add(bookBtn);
        btnPanel.add(cancelBtn);

        add(btnPanel, BorderLayout.CENTER);

        statusArea = new JTextArea();

        add(new JScrollPane(statusArea),
                BorderLayout.SOUTH);

        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {

        String seat =
                seatBox.getSelectedItem().toString();

        if (e.getSource() == bookBtn) {

            statusArea.append(
                    "Seat " + seat +
                    " Booked Successfully\n");

            JOptionPane.showMessageDialog(this,
                    "Booking Confirmed");
        }

        if (e.getSource() == cancelBtn) {

            statusArea.append(
                    "Seat " + seat +
                    " Cancelled\n");

            JOptionPane.showMessageDialog(this,
                    "Booking Cancelled");
        }
    }

    public static void main(String[] args) {

        new TicketBookingSystem();
    }
}