package AT3;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;

public class InventoryManagementDashboard extends JFrame implements ActionListener {

    JTextField txtId, txtName, txtPrice, txtQuantity, txtSearch;
    JButton btnAdd, btnUpdate, btnDelete, btnSearch;

    JTable table;
    DefaultTableModel model;

    public InventoryManagementDashboard() {

        setTitle("Inventory Management Dashboard");
        setSize(800, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(5, 2, 10, 10));

        panel.add(new JLabel("Product ID"));
        txtId = new JTextField();
        panel.add(txtId);

        panel.add(new JLabel("Product Name"));
        txtName = new JTextField();
        panel.add(txtName);

        panel.add(new JLabel("Price"));
        txtPrice = new JTextField();
        panel.add(txtPrice);

        panel.add(new JLabel("Quantity"));
        txtQuantity = new JTextField();
        panel.add(txtQuantity);

        panel.add(new JLabel("Search"));
        txtSearch = new JTextField();
        panel.add(txtSearch);

        add(panel, BorderLayout.NORTH);

        model = new DefaultTableModel();
        model.addColumn("ID");
        model.addColumn("Name");
        model.addColumn("Price");
        model.addColumn("Quantity");

        table = new JTable(model);

        add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel btnPanel = new JPanel();

        btnAdd = new JButton("Add");
        btnUpdate = new JButton("Update");
        btnDelete = new JButton("Delete");
        btnSearch = new JButton("Search");

        btnAdd.addActionListener(this);
        btnUpdate.addActionListener(this);
        btnDelete.addActionListener(this);
        btnSearch.addActionListener(this);

        btnPanel.add(btnAdd);
        btnPanel.add(btnUpdate);
        btnPanel.add(btnDelete);
        btnPanel.add(btnSearch);

        add(btnPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == btnAdd) {

            model.addRow(new Object[]{
                    txtId.getText(),
                    txtName.getText(),
                    txtPrice.getText(),
                    txtQuantity.getText()
            });

            JOptionPane.showMessageDialog(this,
                    "Product Added Successfully");
        }

        if (e.getSource() == btnUpdate) {

            int row = table.getSelectedRow();

            if (row >= 0) {

                model.setValueAt(txtId.getText(), row, 0);
                model.setValueAt(txtName.getText(), row, 1);
                model.setValueAt(txtPrice.getText(), row, 2);
                model.setValueAt(txtQuantity.getText(), row, 3);

                JOptionPane.showMessageDialog(this,
                        "Product Updated");
            }
        }

        if (e.getSource() == btnDelete) {

            int row = table.getSelectedRow();

            if (row >= 0) {
                model.removeRow(row);
                JOptionPane.showMessageDialog(this,
                        "Product Deleted");
            }
        }

        if (e.getSource() == btnSearch) {

            String search = txtSearch.getText();

            for (int i = 0; i < model.getRowCount(); i++) {

                if (model.getValueAt(i, 1).toString()
                        .equalsIgnoreCase(search)) {

                    table.setRowSelectionInterval(i, i);

                    JOptionPane.showMessageDialog(this,
                            "Product Found");

                    return;
                }
            }

            JOptionPane.showMessageDialog(this,
                    "Product Not Found");
        }
    }

    public static void main(String[] args) {
        new InventoryManagementDashboard();
    }
}