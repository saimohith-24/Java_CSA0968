package AT3;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class OnlineBankingGUI extends JFrame implements ActionListener {

    private JTextField accountField, amountField;
    private JTextArea transactionArea;
    private JLabel balanceLabel;

    private double balance = 10000.0;

    JButton transferBtn, balanceBtn, historyBtn;

    public OnlineBankingGUI() {

        setTitle("Online Banking Interface");
        setSize(600, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(7, 2, 10, 10));

        panel.add(new JLabel("Account Number:"));
        accountField = new JTextField();
        panel.add(accountField);

        panel.add(new JLabel("Amount:"));
        amountField = new JTextField();
        panel.add(amountField);

        transferBtn = new JButton("Fund Transfer");
        transferBtn.addActionListener(this);
        panel.add(transferBtn);

        balanceBtn = new JButton("Check Balance");
        balanceBtn.addActionListener(this);
        panel.add(balanceBtn);

        historyBtn = new JButton("Transaction History");
        historyBtn.addActionListener(this);
        panel.add(historyBtn);

        balanceLabel = new JLabel("Current Balance: ₹" + balance);
        panel.add(balanceLabel);

        transactionArea = new JTextArea();
        transactionArea.setEditable(false);

        JScrollPane scrollPane = new JScrollPane(transactionArea);

        add(panel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);

        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == transferBtn) {

            String account = accountField.getText();
            String amountText = amountField.getText();

            if (!account.matches("\\d+")) {
                JOptionPane.showMessageDialog(this,
                        "Invalid Account Number!");
                return;
            }

            try {

                double amount = Double.parseDouble(amountText);

                if (amount <= 0) {
                    JOptionPane.showMessageDialog(this,
                            "Amount must be greater than 0");
                    return;
                }

                if (amount > balance) {
                    JOptionPane.showMessageDialog(this,
                            "Insufficient Balance");
                    return;
                }

                balance -= amount;

                balanceLabel.setText(
                        "Current Balance: ₹" + balance);

                transactionArea.append(
                        "Transferred ₹" + amount +
                        " to Account " + account + "\n");

                JOptionPane.showMessageDialog(this,
                        "Transfer Successful");

            } catch (NumberFormatException ex) {

                JOptionPane.showMessageDialog(this,
                        "Enter Valid Amount");
            }
        }

        else if (e.getSource() == balanceBtn) {

            JOptionPane.showMessageDialog(this,
                    "Available Balance: ₹" + balance);
        }

        else if (e.getSource() == historyBtn) {

            JOptionPane.showMessageDialog(this,
                    "Transaction History Displayed Below");
        }
    }

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {
            new OnlineBankingGUI();
        });
    }
}