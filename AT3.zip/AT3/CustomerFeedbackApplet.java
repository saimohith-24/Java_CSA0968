

import java.applet.Applet;
import java.awt.*;
import java.awt.event.*;

public class CustomerFeedbackApplet extends Applet
        implements ActionListener {

    Label lblName, lblFeedback, lblRating, lblResult;

    TextField txtName;

    TextArea txtFeedback;

    Choice ratingChoice;

    Button submitBtn;

    public void init() {

        setLayout(new FlowLayout());

        lblName = new Label("Customer Name");
        txtName = new TextField(20);

        lblFeedback = new Label("Feedback");
        txtFeedback = new TextArea(5, 20);

        lblRating = new Label("Rating");

        ratingChoice = new Choice();
        ratingChoice.add("1");
        ratingChoice.add("2");
        ratingChoice.add("3");
        ratingChoice.add("4");
        ratingChoice.add("5");

        submitBtn = new Button("Submit");

        lblResult = new Label("");

        submitBtn.addActionListener(this);

        add(lblName);
        add(txtName);

        add(lblFeedback);
        add(txtFeedback);

        add(lblRating);
        add(ratingChoice);

        add(submitBtn);
        add(lblResult);
    }

    public void actionPerformed(ActionEvent e) {

        String name = txtName.getText();
        String feedback = txtFeedback.getText();
        String rating = ratingChoice.getSelectedItem();

        if (name.isEmpty() || feedback.isEmpty()) {

            lblResult.setText(
                    "Please fill all fields");

            return;
        }

        lblResult.setText(
                "Thank You " + name +
                " | Rating: " + rating);
    }
}