import java.util.Scanner;

public class PatternCharTriangle {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the Character to be printed: ");
        String ch = scanner.next();
        System.out.print("Max Number of time printed: ");
        int max = scanner.nextInt();

        for (int i = 1; i <= max; i++) {
            for (int j = 1; j <= i; j++) {
                System.out.print(ch + (j < i ? " " : ""));
            }
            System.out.println();
        }
        scanner.close();
    }
}
