import java.util.Scanner;

public class FibonacciSeries {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the n value: ");
        if (!scanner.hasNextInt()) {
            System.out.println("Invalid Input");
            scanner.close();
            return;
        }
        int n = scanner.nextInt();
        if (n <= 0) {
            System.out.println("Invalid Input");
            scanner.close();
            return;
        }

        long a = 0, b = 1;
        System.out.print(a);
        if (n > 1) {
            System.out.print("\t" + b);
        }
        for (int i = 2; i < n; i++) {
            long next = a + b;
            System.out.print("\t" + next);
            a = b;
            b = next;
        }
        System.out.println();
        scanner.close();
    }
}
