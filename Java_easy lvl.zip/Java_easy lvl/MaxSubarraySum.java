import java.util.Scanner;

public class MaxSubarraySum {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Input nums = ");
        if (!scanner.hasNextLine()) {
            System.out.println("Invalid Input");
            scanner.close();
            return;
        }
        String input = scanner.nextLine().trim();
        // Clean brackets
        input = input.replaceAll("[\\[\\]]", "");
        if (input.isEmpty()) {
            System.out.println("Invalid Input");
            scanner.close();
            return;
        }

        String[] parts = input.split("[,\\s]+");
        int[] nums = new int[parts.length];
        try {
            for (int i = 0; i < parts.length; i++) {
                nums[i] = Integer.parseInt(parts[i].trim());
            }
        } catch (NumberFormatException e) {
            System.out.println("Invalid Input");
            scanner.close();
            return;
        }

        long maxSum = maxSubArray(nums);
        System.out.println("Output: " + maxSum);
        scanner.close();
    }

    public static long maxSubArray(int[] nums) {
        long maxSoFar = nums[0];
        long currMax = nums[0];
        for (int i = 1; i < nums.length; i++) {
            currMax = Math.max((long) nums[i], currMax + nums[i]);
            maxSoFar = Math.max(maxSoFar, currMax);
        }
        return maxSoFar;
    }
}
