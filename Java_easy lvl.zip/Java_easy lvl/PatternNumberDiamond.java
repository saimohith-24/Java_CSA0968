import java.util.Scanner;

public class PatternNumberDiamond {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the peak number: ");
        if (scanner.hasNextInt()) {
            int peak = scanner.nextInt();
            
            // Increasing part
            for (int i = 1; i <= peak; i++) {
                for (int j = 1; j <= i; j++) {
                    System.out.print(i + (j < i ? " " : ""));
                }
                System.out.println();
            }
            
            // Decreasing part
            for (int i = peak - 1; i >= 1; i--) {
                for (int j = 1; j <= i; j++) {
                    System.out.print(i + (j < i ? " " : ""));
                }
                System.out.println();
            }
        }
        scanner.close();
    }
}
