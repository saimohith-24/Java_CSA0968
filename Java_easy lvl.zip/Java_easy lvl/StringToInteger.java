import java.util.Scanner;

public class StringToInteger {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("String: ");
        if (scanner.hasNextLine()) {
            String str = scanner.nextLine().trim();
            try {
                int result = convertToInt(str);
                System.out.println("Out put String: " + result);
            } catch (NumberFormatException e) {
                System.out.println("Out put String: Invalid (" + e.getMessage() + ")");
            }
        }
        scanner.close();
    }

    public static int convertToInt(String str) {
        if (str == null || str.isEmpty()) {
            throw new NumberFormatException("Empty string");
        }
        int i = 0;
        boolean isNegative = false;
        if (str.charAt(0) == '-') {
            isNegative = true;
            i++;
        } else if (str.charAt(0) == '+') {
            i++;
        }
        if (i == str.length()) {
            throw new NumberFormatException("No digits found");
        }
        int num = 0;
        while (i < str.length()) {
            char c = str.charAt(i);
            if (c < '0' || c > '9') {
                throw new NumberFormatException("Invalid digit: " + c);
            }
            int digit = c - '0';
            // Simple overflow check
            if (num > (Integer.MAX_VALUE - digit) / 10) {
                throw new NumberFormatException("Integer overflow");
            }
            num = num * 10 + digit;
            i++;
        }
        return isNegative ? -num : num;
    }
}
