import java.util.Scanner;

public class InvertedFullPyramid {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter number of rows: ");
        if (scanner.hasNextInt()) {
            int n = scanner.nextInt();
            for (int i = 0; i < n; i++) {
                // Print leading spaces
                for (int j = 0; j < i; j++) {
                    System.out.print(" ");
                }
                // Print stars separated by spaces
                for (int j = 0; j < n - i; j++) {
                    System.out.print("*" + (j < n - i - 1 ? " " : ""));
                }
                System.out.println();
            }
        }
        scanner.close();
    }
}
