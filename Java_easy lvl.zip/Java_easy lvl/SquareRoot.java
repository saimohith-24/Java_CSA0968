import java.util.Scanner;

public class SquareRoot {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the number: ");
        if (!scanner.hasNextLine()) {
            System.out.println("Invalid Input");
            scanner.close();
            return;
        }
        String input = scanner.nextLine().trim();
        try {
            if (input.contains(".")) {
                System.out.println("Invalid Input");
                scanner.close();
                return;
            }
            long num = Long.parseLong(input);
            if (num < 0) {
                System.out.println("Not a perfect square");
                scanner.close();
                return;
            }

            long root = (long) Math.round(Math.sqrt(num));
            if (root * root == num) {
                if (root == 0) {
                    System.out.println("Square Root: 0");
                } else {
                    System.out.println("Square Root: " + root + ", -" + root);
                }
            } else {
                System.out.println("Not a perfect square");
            }
        } catch (NumberFormatException e) {
            System.out.println("Invalid Input");
        }
        scanner.close();
    }
}
