import java.util.Scanner;

public class NumberOfVowels {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter string: ");
        if (scanner.hasNextLine()) {
            String str = scanner.nextLine();
            int count = 0;
            String vowels = "aeiouAEIOU";
            for (int i = 0; i < str.length(); i++) {
                if (vowels.indexOf(str.charAt(i)) != -1) {
                    count++;
                }
            }
            System.out.println("Number of vowels = " + count);
        }
        scanner.close();
    }
}
