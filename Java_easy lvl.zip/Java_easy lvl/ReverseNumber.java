import java.util.Scanner;

public class ReverseNumber {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Number: ");
        if (!scanner.hasNextLine()) {
            System.out.println("Invalid Input");
            scanner.close();
            return;
        }
        String input = scanner.nextLine().trim();
        if (input.isEmpty()) {
            System.out.println("Invalid Input");
            scanner.close();
            return;
        }

        try {
            long num = Long.parseLong(input);
            boolean isNegative = num < 0;
            long absNum = Math.abs(num);
            long reversed = 0;

            // Loop to reverse the number
            long temp = absNum;
            while (temp > 0) {
                long digit = temp % 10;
                reversed = reversed * 10 + digit;
                temp /= 10;
            }

            if (isNegative) {
                reversed = -reversed;
            }

            System.out.println("Reverse Number: " + reversed);
        } catch (NumberFormatException e) {
            System.out.println("Invalid Input");
        }
        scanner.close();
    }
}
