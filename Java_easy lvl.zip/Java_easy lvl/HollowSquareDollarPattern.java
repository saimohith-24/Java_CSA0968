import java.util.Scanner;

public class HollowSquareDollarPattern {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter size of square: ");
        if (!scanner.hasNextInt()) {
            System.out.println("Invalid Input");
            scanner.close();
            return;
        }
        int n = scanner.nextInt();
        if (n <= 0) {
            System.out.println("Invalid Input");
            scanner.close();
            return;
        }

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (i == 0 || i == n - 1 || j == 0 || j == n - 1) {
                    System.out.print("$ ");
                } else {
                    System.out.print("  ");
                }
            }
            System.out.println();
        }
        scanner.close();
    }
}
