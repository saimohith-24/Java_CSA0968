import java.util.Scanner;

public class SortNames {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter number of names: ");
        int n = 0;
        if (scanner.hasNextInt()) {
            n = scanner.nextInt();
            scanner.nextLine(); // consume newline
        } else {
            System.out.println("Invalid input.");
            scanner.close();
            return;
        }

        String[] names = new String[n];
        System.out.println("Enter the names:");
        for (int i = 0; i < n; i++) {
            names[i] = scanner.nextLine();
        }

        System.out.print("Order(A/D) : ");
        String order = scanner.nextLine().trim();

        // Sort names using bubble sort
        for (int i = 0; i < n - 1; i++) {
            for (int j = i + 1; j < n; j++) {
                boolean swap = false;
                int cmp = names[i].compareTo(names[j]);
                if (order.equalsIgnoreCase("D")) {
                    if (cmp < 0) swap = true;
                } else {
                    if (cmp > 0) swap = true;
                }
                if (swap) {
                    String temp = names[i];
                    names[i] = names[j];
                    names[j] = temp;
                }
            }
        }

        System.out.println("\nSorted Names:");
        for (String name : names) {
            System.out.println(name);
        }
        scanner.close();
    }
}
