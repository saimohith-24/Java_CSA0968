import java.util.Scanner;

public class PowerOfThree {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Input = ");
        if (!scanner.hasNextLine()) {
            System.out.println("Invalid Input");
            scanner.close();
            return;
        }
        String input = scanner.nextLine().trim();
        try {
            if (input.contains(".")) {
                System.out.println("Invalid Input");
                scanner.close();
                return;
            }
            long n = Long.parseLong(input);
            boolean result = isPowerOfThree(n);
            System.out.println("Output= " + result);
        } catch (NumberFormatException e) {
            System.out.println("Invalid Input");
        }
        scanner.close();
    }

    public static boolean isPowerOfThree(long n) {
        if (n <= 0) {
            return false;
        }
        while (n % 3 == 0) {
            n /= 3;
        }
        return n == 1;
    }
}
