import java.util.Scanner;

public class VotingEligibility {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter your age: ");
        if (!scanner.hasNextLine()) {
            System.out.println("Invalid Input");
            scanner.close();
            return;
        }
        String input = scanner.nextLine().trim();
        try {
            if (input.contains(".")) {
                System.out.println("Invalid Input");
                scanner.close();
                return;
            }
            int age = Integer.parseInt(input);
            if (age <= 0) {
                System.out.println("Invalid Input");
                scanner.close();
                return;
            }

            if (age >= 18) {
                System.out.println("You are eligible to vote");
            } else {
                int yearsLeft = 18 - age;
                System.out.println("You are allowed to vote after " + yearsLeft + " years");
            }
        } catch (NumberFormatException e) {
            System.out.println("Invalid Input");
        }
        scanner.close();
    }
}
