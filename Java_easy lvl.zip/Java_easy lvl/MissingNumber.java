import java.util.Scanner;
import java.util.HashSet;
import java.util.Set;

public class MissingNumber {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Input nums = ");
        if (!scanner.hasNextLine()) {
            System.out.println("Invalid Input");
            scanner.close();
            return;
        }
        String input = scanner.nextLine().trim();
        // Clean brackets
        input = input.replaceAll("[\\[\\]]", "");
        if (input.isEmpty()) {
            System.out.println("Invalid Input");
            scanner.close();
            return;
        }

        String[] parts = input.split("[,\\s]+");
        int n = parts.length;
        int[] nums = new int[n];
        try {
            for (int i = 0; i < n; i++) {
                nums[i] = Integer.parseInt(parts[i].trim());
            }
        } catch (NumberFormatException e) {
            System.out.println("Invalid Input");
            scanner.close();
            return;
        }

        // Validate distinct elements in [0, n]
        Set<Integer> seen = new HashSet<>();
        long sum = 0;
        for (int val : nums) {
            if (val < 0 || val > n) {
                System.out.println("Invalid Input");
                scanner.close();
                return;
            }
            if (seen.contains(val)) {
                System.out.println("Invalid Input");
                scanner.close();
                return;
            }
            seen.add(val);
            sum += val;
        }

        long expectedSum = (long) n * (n + 1) / 2;
        long missing = expectedSum - sum;

        System.out.println("Output: " + missing);
        scanner.close();
    }
}
