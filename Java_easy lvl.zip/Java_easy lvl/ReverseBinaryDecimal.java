import java.util.Scanner;

public class ReverseBinaryDecimal {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a decimal number: ");
        if (!scanner.hasNextLine()) {
            System.out.println("Invalid Input");
            scanner.close();
            return;
        }
        String input = scanner.nextLine().trim();
        try {
            // Check if input is a float
            if (input.contains(".")) {
                System.out.println("Invalid Input");
                scanner.close();
                return;
            }
            long decimalVal = Long.parseLong(input);
            if (decimalVal < 0) {
                System.out.println("Invalid Input");
                scanner.close();
                return;
            }

            // Convert to binary
            String binaryStr = Long.toBinaryString(decimalVal);
            // Reverse the binary string
            String reversedBinaryStr = new StringBuilder(binaryStr).reverse().toString();
            // Parse back to decimal
            long result = Long.parseLong(reversedBinaryStr, 2);

            System.out.println("Output: " + result);
        } catch (NumberFormatException e) {
            System.out.println("Invalid Input");
        }
        scanner.close();
    }
}
