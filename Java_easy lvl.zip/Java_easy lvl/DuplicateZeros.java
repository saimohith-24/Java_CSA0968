import java.util.Scanner;
import java.util.Arrays;

public class DuplicateZeros {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter array (e.g. [1, 0, 2, 3, 0, 4, 5, 0]): ");
        if (!scanner.hasNextLine()) {
            System.out.println("Invalid Input");
            scanner.close();
            return;
        }
        String input = scanner.nextLine().trim();
        // Clean brackets
        input = input.replaceAll("[\\[\\]]", "");
        if (input.isEmpty()) {
            System.out.println("Invalid Input");
            scanner.close();
            return;
        }

        String[] parts = input.split("[,\\s]+");
        int[] arr = new int[parts.length];
        try {
            for (int i = 0; i < parts.length; i++) {
                arr[i] = Integer.parseInt(parts[i].trim());
            }
        } catch (NumberFormatException e) {
            System.out.println("Invalid Input");
            scanner.close();
            return;
        }

        duplicateZeros(arr);

        System.out.println("Output: " + Arrays.toString(arr));
        scanner.close();
    }

    public static void duplicateZeros(int[] arr) {
        int possibleDups = 0;
        int length = arr.length - 1;

        // Find the number of zeros to be duplicated
        for (int left = 0; left <= length - possibleDups; left++) {
            if (arr[left] == 0) {
                // Edge case: This zero cannot be duplicated because there is no space for duplicate
                if (left == length - possibleDups) {
                    arr[length] = 0;
                    length -= 1;
                    break;
                }
                possibleDups++;
            }
        }

        // Start copying from the end
        int last = length - possibleDups;
        for (int i = last; i >= 0; i--) {
            if (arr[i] == 0) {
                arr[i + possibleDups] = 0;
                possibleDups--;
                arr[i + possibleDups] = 0;
            } else {
                arr[i + possibleDups] = arr[i];
            }
        }
    }
}
