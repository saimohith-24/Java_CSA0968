import java.util.ArrayList;
import java.util.Scanner;

public class MergeSortedArrays {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter size of array 1: ");
        int n1 = scanner.nextInt();
        int[] arr1 = new int[n1];
        System.out.println("Enter sorted elements of array 1:");
        for (int i = 0; i < n1; i++) {
            arr1[i] = scanner.nextInt();
        }

        System.out.print("Enter size of array 2: ");
        int n2 = scanner.nextInt();
        int[] arr2 = new int[n2];
        System.out.println("Enter sorted elements of array 2:");
        for (int i = 0; i < n2; i++) {
            arr2[i] = scanner.nextInt();
        }

        ArrayList<Integer> arr3 = new ArrayList<>();
        int i = 0, j = 0;
        while (i < n1 && j < n2) {
            if (arr1[i] <= arr2[j]) {
                arr3.add(arr1[i]);
                i++;
            } else {
                arr3.add(arr2[j]);
                j++;
            }
        }

        while (i < n1) {
            arr3.add(arr1[i]);
            i++;
        }

        while (j < n2) {
            arr3.add(arr2[j]);
            j++;
        }

        System.out.print("arr3[] = {");
        for (int k = 0; k < arr3.size(); k++) {
            System.out.print(arr3.get(k) + (k < arr3.size() - 1 ? ", " : ""));
        }
        System.out.println("}");
        scanner.close();
    }
}
