import java.util.Scanner;
import java.util.Arrays;
import java.util.HashMap;

public class MeanMedianMode {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the number of elements: ");
        if (!scanner.hasNextInt()) {
            System.out.println("Invalid input size.");
            scanner.close();
            return;
        }
        int n = scanner.nextInt();
        if (n <= 0) {
            System.out.println("Size must be positive.");
            scanner.close();
            return;
        }
        
        double[] arr = new double[n];
        System.out.println("Enter the elements:");
        for (int i = 0; i < n; i++) {
            arr[i] = scanner.nextDouble();
        }

        // Mean
        double sum = 0;
        for (double val : arr) {
            sum += val;
        }
        double mean = sum / n;

        // Median
        Arrays.sort(arr);
        double median;
        if (n % 2 != 0) {
            median = arr[n / 2];
        } else {
            median = (arr[n / 2 - 1] + arr[n / 2]) / 2.0;
        }

        // Mode
        HashMap<Double, Integer> freqMap = new HashMap<>();
        for (double val : arr) {
            freqMap.put(val, freqMap.getOrDefault(val, 0) + 1);
        }

        double mode = arr[0];
        int maxCount = 0;
        // In case of multiple modes, the first one encountered in sorted order with max count is selected
        for (double val : arr) {
            int count = freqMap.get(val);
            if (count > maxCount) {
                maxCount = count;
                mode = val;
            }
        }

        System.out.println("Mean = " + formatVal(mean));
        System.out.println("Median = " + formatVal(median));
        System.out.println("Mode = " + formatVal(mode));
        scanner.close();
    }

    private static String formatVal(double val) {
        if (val == (long) val) {
            return String.format("%d", (long) val);
        } else {
            return String.format("%s", val);
        }
    }
}
