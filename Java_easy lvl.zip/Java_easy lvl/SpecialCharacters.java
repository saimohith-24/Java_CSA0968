import java.util.Scanner;

public class SpecialCharacters {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a line of text: ");
        if (scanner.hasNextLine()) {
            String line = scanner.nextLine();
            int count = 0;
            StringBuilder specialChars = new StringBuilder();
            for (int i = 0; i < line.length(); i++) {
                char ch = line.charAt(i);
                // Check if it's not a letter, digit, or whitespace
                if (!Character.isLetterOrDigit(ch) && !Character.isWhitespace(ch)) {
                    specialChars.append(ch).append(" ");
                    count++;
                }
            }
            System.out.println("Special Characters: " + specialChars.toString().trim());
            System.out.println("Number of Special Characters = " + count);
        }
        scanner.close();
    }
}
