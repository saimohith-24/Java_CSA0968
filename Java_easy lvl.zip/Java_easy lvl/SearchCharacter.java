import java.util.Scanner;

public class SearchCharacter {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the string: ");
        String str = scanner.nextLine();
        System.out.print("Enter the character to be searched: ");
        String searchInput = scanner.nextLine();
        
        if (searchInput.length() == 0) {
            System.out.println("No character entered.");
            scanner.close();
            return;
        }
        
        char searchChar = searchInput.charAt(0);
        int index = -1;
        // Search without built-in find functions
        for (int i = 0; i < str.length(); i++) {
            if (str.charAt(i) == searchChar) {
                index = i;
                break;
            }
        }
        
        if (index != -1) {
            char displayChar = Character.toUpperCase(searchChar);
            System.out.println(displayChar + " is found in string at index: " + (index + 1));
        } else {
            System.out.println(searchChar + " is not found in string.");
        }
        scanner.close();
    }
}
