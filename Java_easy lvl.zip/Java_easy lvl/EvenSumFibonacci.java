import java.util.Scanner;

public class EvenSumFibonacci {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the n value: ");
        if (!scanner.hasNextInt()) {
            System.out.println("Invalid Input");
            scanner.close();
            return;
        }
        int n = scanner.nextInt();
        if (n < 0) {
            System.out.println("Invalid Input");
            scanner.close();
            return;
        }

        long sum = 0;
        long a = 0; // term at index 0
        long b = 1; // term at index 1

        if (n >= 0) {
            sum += a; // add term at index 0
        }

        long prev2 = a;
        long prev1 = b;

        for (int i = 2; i <= 2 * n; i++) {
            long current = prev1 + prev2;
            if (i % 2 == 0) {
                sum += current;
            }
            prev2 = prev1;
            prev1 = current;
        }

        System.out.println("Sum of numbers at even indexes = " + sum);
        scanner.close();
    }
}
