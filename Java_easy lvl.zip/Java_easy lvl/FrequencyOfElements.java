import java.util.Scanner;
import java.util.LinkedHashMap;
import java.util.Map;

public class FrequencyOfElements {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the number of elements: ");
        if (!scanner.hasNextInt()) {
            System.out.println("Invalid Input");
            scanner.close();
            return;
        }
        int n = scanner.nextInt();
        if (n <= 0) {
            System.out.println("Invalid Input");
            scanner.close();
            return;
        }

        int[] arr = new int[n];
        System.out.println("Enter the elements:");
        for (int i = 0; i < n; i++) {
            if (!scanner.hasNextInt()) {
                System.out.println("Invalid Input");
                scanner.close();
                return;
            }
            arr[i] = scanner.nextInt();
        }

        LinkedHashMap<Integer, Integer> freqMap = new LinkedHashMap<>();
        for (int val : arr) {
            freqMap.put(val, freqMap.getOrDefault(val, 0) + 1);
        }

        System.out.println("Element | Frequency");
        System.out.println("--------------------------");
        for (Map.Entry<Integer, Integer> entry : freqMap.entrySet()) {
            System.out.printf("%-7d | %9d\n", entry.getKey(), entry.getValue());
        }
        scanner.close();
    }
}
