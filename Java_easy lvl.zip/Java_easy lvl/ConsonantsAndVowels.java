import java.util.Scanner;

public class ConsonantsAndVowels {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Given Word: ");
        if (scanner.hasNextLine()) {
            String word = scanner.nextLine();
            StringBuilder vowels = new StringBuilder();
            StringBuilder consonants = new StringBuilder();
            
            for (int i = 0; i < word.length(); i++) {
                char ch = word.charAt(i);
                if (Character.isLetter(ch)) {
                    char lowerCh = Character.toLowerCase(ch);
                    if (lowerCh == 'a' || lowerCh == 'e' || lowerCh == 'i' || lowerCh == 'o' || lowerCh == 'u') {
                        vowels.append(lowerCh).append(" ");
                    } else {
                        consonants.append(lowerCh).append(" ");
                    }
                }
            }
            
            System.out.println("Consonants: " + consonants.toString().trim());
            System.out.println("Vowels: " + vowels.toString().trim());
        }
        scanner.close();
    }
}
