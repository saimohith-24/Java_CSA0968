import java.util.Scanner;

public class PatternSquareTriangle {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter number of rows: ");
        if (scanner.hasNextInt()) {
            int n = scanner.nextInt();
            int current = 1;
            for (int i = 1; i <= n; i++) {
                for (int j = 1; j <= i; j++) {
                    System.out.print((current * current) + "\t");
                    current++;
                }
                System.out.println();
            }
        }
        scanner.close();
    }
}
