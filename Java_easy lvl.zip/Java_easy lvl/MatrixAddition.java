import java.util.Scanner;

public class MatrixAddition {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter rows and columns of the matrices: ");
        int r = scanner.nextInt();
        int c = scanner.nextInt();

        int[][] mat1 = new int[r][c];
        System.out.println("Enter elements of Matrix 1:");
        for (int i = 0; i < r; i++) {
            for (int j = 0; j < c; j++) {
                mat1[i][j] = scanner.nextInt();
            }
        }

        int[][] mat2 = new int[r][c];
        System.out.println("Enter elements of Matrix 2:");
        for (int i = 0; i < r; i++) {
            for (int j = 0; j < c; j++) {
                mat2[i][j] = scanner.nextInt();
            }
        }

        int[][] sum = new int[r][c];
        for (int i = 0; i < r; i++) {
            for (int j = 0; j < c; j++) {
                sum[i][j] = mat1[i][j] + mat2[i][j];
            }
        }

        System.out.println("Mat Sum = ");
        for (int i = 0; i < r; i++) {
            for (int j = 0; j < c; j++) {
                System.out.print(sum[i][j] + "\t");
            }
            System.out.println();
        }
        scanner.close();
    }
}
