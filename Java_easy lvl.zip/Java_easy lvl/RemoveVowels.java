import java.util.Scanner;

public class RemoveVowels {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a string: ");
        if (scanner.hasNextLine()) {
            String str = scanner.nextLine();
            StringBuilder result = new StringBuilder();
            String vowels = "aeiouAEIOU";
            for (int i = 0; i < str.length(); i++) {
                char ch = str.charAt(i);
                if (vowels.indexOf(ch) == -1) {
                    result.append(ch);
                }
            }
            System.out.println("The string without vowels is: " + result.toString());
        }
        scanner.close();
    }
}
