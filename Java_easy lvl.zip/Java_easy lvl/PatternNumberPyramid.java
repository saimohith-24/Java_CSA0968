import java.util.Scanner;

public class PatternNumberPyramid {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the number to be printed: ");
        String num = scanner.next();
        System.out.print("Max Number of time printed: ");
        int max = scanner.nextInt();

        // Increasing part
        for (int i = 1; i <= max; i++) {
            for (int j = 1; j <= i; j++) {
                System.out.print(num);
            }
            System.out.println();
        }

        // Decreasing part
        for (int i = max - 1; i >= 1; i--) {
            for (int j = 1; j <= i; j++) {
                System.out.print(num);
            }
            System.out.println();
        }
        scanner.close();
    }
}
