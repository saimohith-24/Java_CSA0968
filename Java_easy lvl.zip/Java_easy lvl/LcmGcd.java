import java.util.Scanner;

public class LcmGcd {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("N value = ");
        if (!scanner.hasNextInt()) {
            System.out.println("Invalid Input");
            scanner.close();
            return;
        }
        int n = scanner.nextInt();
        if (n <= 0) {
            System.out.println("Invalid Input");
            scanner.close();
            return;
        }

        long[] numbers = new long[n];
        for (int i = 0; i < n; i++) {
            System.out.print("Number " + (i + 1) + " = ");
            if (!scanner.hasNextLong()) {
                System.out.println("Invalid Input");
                scanner.close();
                return;
            }
            numbers[i] = scanner.nextLong();
            if (numbers[i] <= 0) {
                System.out.println("Invalid Input");
                scanner.close();
                return;
            }
        }

        long currentGcd = numbers[0];
        long currentLcm = numbers[0];
        for (int i = 1; i < n; i++) {
            currentGcd = gcd(currentGcd, numbers[i]);
            currentLcm = lcm(currentLcm, numbers[i]);
        }

        System.out.println("LCM = " + currentLcm);
        System.out.println("GCD = " + currentGcd);
        scanner.close();
    }

    public static long gcd(long a, long b) {
        while (b != 0) {
            long temp = b;
            b = a % b;
            a = temp;
        }
        return a;
    }

    public static long lcm(long a, long b) {
        if (a == 0 || b == 0) return 0;
        return (a / gcd(a, b)) * b;
    }
}
