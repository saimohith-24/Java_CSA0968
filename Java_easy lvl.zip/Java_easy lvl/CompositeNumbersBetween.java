import java.util.Scanner;

public class CompositeNumbersBetween {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("A = ");
        if (!scanner.hasNextInt()) {
            System.out.println("Invalid Input");
            scanner.close();
            return;
        }
        int a = scanner.nextInt();
        
        System.out.print("B = ");
        if (!scanner.hasNextInt()) {
            System.out.println("Invalid Input");
            scanner.close();
            return;
        }
        int b = scanner.nextInt();

        int start = Math.min(a, b);
        int end = Math.max(a, b);
        
        boolean first = true;
        for (int i = start; i <= end; i++) {
            if (isComposite(i)) {
                if (!first) {
                    System.out.print(", ");
                }
                System.out.print(i);
                first = false;
            }
        }
        System.out.println();
        scanner.close();
    }

    public static boolean isComposite(int num) {
        if (num <= 3) {
            return false;
        }
        for (int i = 2; i <= Math.sqrt(num); i++) {
            if (num % i == 0) {
                return true;
            }
        }
        return false;
    }
}
