import java.util.Scanner;

public class NumberOfFactors {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Given number: ");
        if (!scanner.hasNextLine()) {
            System.out.println("Invalid Input");
            scanner.close();
            return;
        }
        String input = scanner.nextLine().trim();
        try {
            if (input.contains(".")) {
                System.out.println("Invalid Input");
                scanner.close();
                return;
            }
            long num = Long.parseLong(input);
            if (num == 0) {
                System.out.println("Invalid Input");
                scanner.close();
                return;
            }

            long absNum = Math.abs(num);
            long count = 0;
            for (long i = 1; i * i <= absNum; i++) {
                if (absNum % i == 0) {
                    if (i * i == absNum) {
                        count++;
                    } else {
                        count += 2;
                    }
                }
            }

            System.out.println("Number of factors = " + count);
        } catch (NumberFormatException e) {
            System.out.println("Invalid Input");
        }
        scanner.close();
    }
}
