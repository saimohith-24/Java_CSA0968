import java.util.Scanner;

public class SquareCubeDecimal {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Given Number: ");
        if (!scanner.hasNextDouble()) {
            System.out.println("Invalid Input");
            scanner.close();
            return;
        }
        double num = scanner.nextDouble();

        double square = num * num;
        double cube = num * num * num;

        System.out.println("Square Number: " + formatVal(square));
        System.out.println("Cube Number: " + formatVal(cube));
        scanner.close();
    }

    private static String formatVal(double val) {
        if (val == (long) val) {
            return String.format("%d", (long) val);
        } else {
            String str = Double.toString(val);
            if (str.endsWith(".0")) {
                return str.substring(0, str.length() - 2);
            }
            return str;
        }
    }
}
