import java.util.Scanner;

public class ArmstrongNumber {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter number: ");
        if (!scanner.hasNextLine()) {
            System.out.println("Invalid Input");
            scanner.close();
            return;
        }
        String input = scanner.nextLine().trim();
        try {
            if (input.contains(".")) {
                System.out.println("Invalid Input");
                scanner.close();
                return;
            }
            long num = Long.parseLong(input);
            if (num < 0) {
                System.out.println("Invalid Input");
                scanner.close();
                return;
            }

            if (isArmstrong(num)) {
                System.out.println("Given number is Armstrong number");
            } else {
                System.out.println("Given number is not Armstrong number");
            }
        } catch (NumberFormatException e) {
            System.out.println("Invalid Input");
        }
        scanner.close();
    }

    public static boolean isArmstrong(long num) {
        if (num == 0) return true;
        long temp = num;
        int d = String.valueOf(num).length();
        long sum = 0;
        while (temp > 0) {
            long digit = temp % 10;
            // Math.pow returns double, cast to long
            long term = 1;
            for (int i = 0; i < d; i++) {
                term *= digit;
            }
            sum += term;
            temp /= 10;
          }
          return sum == num;
      }
  }
  
