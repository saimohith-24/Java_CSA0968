import java.util.Scanner;

public class PerfectNumber {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Given Number: ");
        if (!scanner.hasNextLine()) {
            System.out.println("Invalid Input");
            scanner.close();
            return;
        }
        String input = scanner.nextLine().trim();
        try {
            if (input.contains(".")) {
                System.out.println("Invalid Input");
                scanner.close();
                return;
            }
            long num = Long.parseLong(input);
            if (num <= 0) {
                System.out.println("Invalid Input");
                scanner.close();
                return;
            }

            long sum = 0;
            for (long i = 1; i <= num / 2; i++) {
                if (num % i == 0) {
                    sum += i;
                }
            }

            if (sum == num) {
                System.out.println("It's a Perfect Number");
            } else {
                System.out.println("It's not a Perfect Number");
            }
        } catch (NumberFormatException e) {
            System.out.println("Invalid Input");
        }
        scanner.close();
    }
}
