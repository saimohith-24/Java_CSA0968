import java.util.Scanner;

public class LeapYearCheck {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter Date (dd/mm/yyyy or mm/dd/yyyy): ");
        if (!scanner.hasNextLine()) {
            System.out.println("Invalid Date");
            scanner.close();
            return;
        }
        String input = scanner.nextLine().trim();
        String[] parts = input.split("/");
        if (parts.length != 3) {
            System.out.println("Invalid Date");
            scanner.close();
            return;
        }

        try {
            if (parts[0].contains(".") || parts[1].contains(".") || parts[2].contains(".")) {
                System.out.println("Invalid Date");
                scanner.close();
                return;
            }
            int p1 = Integer.parseInt(parts[0]);
            int p2 = Integer.parseInt(parts[1]);
            int year = Integer.parseInt(parts[2]);

            if (year <= 0) {
                System.out.println("Invalid Date");
                scanner.close();
                return;
            }

            boolean caseA = isValidDate(p1, p2, year); // p1 is day, p2 is month
            boolean caseB = isValidDate(p2, p1, year); // p2 is day, p1 is month

            if (!caseA && !caseB) {
                System.out.println("Invalid Date");
            } else {
                if (isLeap(year)) {
                    System.out.println("Given year is Leap Year");
                } else {
                    System.out.println("Given year is Non Leap Year");
                }
            }
        } catch (NumberFormatException e) {
            System.out.println("Invalid Date");
        }
        scanner.close();
    }

    public static boolean isLeap(int y) {
        if (y % 4 != 0) return false;
        if (y % 100 != 0) return true;
        return y % 400 == 0;
    }

    public static boolean isValidDate(int day, int month, int year) {
        if (month < 1 || month > 12) return false;
        if (day < 1) return false;

        int[] daysInMonth = {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
        if (isLeap(year)) {
            daysInMonth[2] = 29;
        }

        return day <= daysInMonth[month];
    }
}
