import java.util.Scanner;
import java.util.HashSet;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class MostFrequentWord {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter Paragraph: ");
        if (!scanner.hasNextLine()) {
            System.out.println("Invalid Input");
            scanner.close();
            return;
        }
        String paragraph = scanner.nextLine();

        System.out.print("Enter Banned words: ");
        if (!scanner.hasNextLine()) {
            System.out.println("Invalid Input");
            scanner.close();
            return;
        }
        String bannedInput = scanner.nextLine().trim();

        // Clean banned input of brackets and split by comma
        bannedInput = bannedInput.replaceAll("[\\[\\]]", "");
        String[] bannedParts = bannedInput.split(",");
        Set<String> bannedSet = new HashSet<>();
        for (String b : bannedParts) {
            bannedSet.add(b.trim().toLowerCase());
        }

        // Clean paragraph: replace non-alphanumeric symbols with space
        String cleaned = paragraph.replaceAll("[^a-zA-Z0-9\\s]", " ");
        String[] words = cleaned.split("\\s+");

        Map<String, Integer> freqMap = new HashMap<>();
        for (String w : words) {
            String word = w.trim().toLowerCase();
            if (word.isEmpty() || bannedSet.contains(word)) {
                continue;
            }
            freqMap.put(word, freqMap.getOrDefault(word, 0) + 1);
        }

        String mostFrequent = "";
        int maxFreq = 0;
        for (Map.Entry<String, Integer> entry : freqMap.entrySet()) {
            if (entry.getValue() > maxFreq) {
                maxFreq = entry.getValue();
                mostFrequent = entry.getKey();
            }
        }

        if (!mostFrequent.isEmpty()) {
            String capitalized = mostFrequent.substring(0, 1).toUpperCase() + mostFrequent.substring(1);
            System.out.println("Output= " + capitalized);
        } else {
            System.out.println("No valid word found");
        }
        scanner.close();
    }
}
