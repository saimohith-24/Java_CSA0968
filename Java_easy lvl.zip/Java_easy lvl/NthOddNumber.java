import java.util.Scanner;

public class NthOddNumber {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("N : ");
        if (!scanner.hasNextLine()) {
            System.out.println("Invalid Input");
            scanner.close();
            return;
        }
        String input = scanner.nextLine().trim();
        try {
            if (input.contains(".")) {
                System.out.println("Invalid Input");
                scanner.close();
                return;
            }
            int n = Integer.parseInt(input);
            if (n <= 0) {
                System.out.println("Invalid Input");
                scanner.close();
                return;
            }

            // Print the first N odd numbers
            System.out.print("Hence the values printed for i are ");
            for (int i = 1; i <= 2 * n; i += 2) {
                System.out.print(i + (i < 2 * n - 1 ? " , " : "."));
            }
            System.out.println();

            int nthOdd = 4 * n - 1;
            System.out.println("The " + n + "th odd number after " + n + " odd numbers is: " + nthOdd);
        } catch (NumberFormatException e) {
            System.out.println("Invalid Input");
        }
        scanner.close();
    }
}
