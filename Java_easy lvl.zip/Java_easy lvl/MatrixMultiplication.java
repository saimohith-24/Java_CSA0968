import java.util.Scanner;

public class MatrixMultiplication {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter rows and columns of Matrix 1: ");
        int r1 = scanner.nextInt();
        int c1 = scanner.nextInt();
        int[][] mat1 = new int[r1][c1];
        System.out.println("Enter elements of Matrix 1:");
        for (int i = 0; i < r1; i++) {
            for (int j = 0; j < c1; j++) {
                mat1[i][j] = scanner.nextInt();
            }
        }

        System.out.print("Enter rows and columns of Matrix 2: ");
        int r2 = scanner.nextInt();
        int c2 = scanner.nextInt();
        int[][] mat2 = new int[r2][c2];
        System.out.println("Enter elements of Matrix 2:");
        for (int i = 0; i < r2; i++) {
            for (int j = 0; j < c2; j++) {
                mat2[i][j] = scanner.nextInt();
            }
        }

        if (c1 != r2) {
            System.out.println("Matrix multiplication not possible.");
            scanner.close();
            return;
        }

        int[][] product = new int[r1][c2];
        for (int i = 0; i < r1; i++) {
            for (int j = 0; j < c2; j++) {
                for (int k = 0; k < c1; k++) {
                    product[i][j] += mat1[i][k] * mat2[k][j];
                }
            }
        }

        System.out.println("Mat Sum = ");
        for (int i = 0; i < r1; i++) {
            for (int j = 0; j < c2; j++) {
                System.out.print(product[i][j] + "\t");
            }
            System.out.println();
        }
        scanner.close();
    }
}
