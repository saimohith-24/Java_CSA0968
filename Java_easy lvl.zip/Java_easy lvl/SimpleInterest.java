import java.util.Scanner;

public class SimpleInterest {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter the principal amount: ");
        if (!scanner.hasNextDouble()) {
            System.out.println("Invalid Input");
            scanner.close();
            return;
        }
        double principal = scanner.nextDouble();
        
        System.out.print("Enter the no of years: ");
        if (!scanner.hasNextDouble()) {
            System.out.println("Invalid Input");
            scanner.close();
            return;
        }
        double years = scanner.nextDouble();
        
        System.out.print("Is customer senior citizen (y/n): ");
        String senior = scanner.next().trim().toLowerCase();
        
        if (principal < 0 || years < 0 || (!senior.equals("y") && !senior.equals("n"))) {
            System.out.println("Invalid Input");
            scanner.close();
            return;
        }

        double roi = senior.equals("y") ? 12.0 : 10.0;
        double interest = calculateInterest(principal, years, roi);
        
        // Print interest. If it's a whole number, format as integer.
        if (interest == (long) interest) {
            System.out.printf("Interest: %d\n", (long) interest);
        } else {
            System.out.printf("Interest: %s\n", interest);
        }
        scanner.close();
    }

    public static double calculateInterest(double p, double t, double r) {
        return (p * r * t) / 100.0;
    }
}
