import java.util.Scanner;

public class ReverseWord {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("String: ");
        if (scanner.hasNextLine()) {
            String str = scanner.nextLine();
            String reversed = "";
            for (int i = str.length() - 1; i >= 0; i--) {
                reversed += str.charAt(i);
            }
            System.out.println("Reverse String: " + reversed);
        }
        scanner.close();
    }
}
