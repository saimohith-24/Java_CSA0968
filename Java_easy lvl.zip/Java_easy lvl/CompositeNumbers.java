import java.util.Scanner;

public class CompositeNumbers {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the number of elements: ");
        if (!scanner.hasNextInt()) {
            System.out.println("Invalid input size.");
            scanner.close();
            return;
        }
        int n = scanner.nextInt();
        double[] arr = new double[n];
        System.out.println("Enter the elements:");
        for (int i = 0; i < n; i++) {
            arr[i] = scanner.nextDouble();
        }

        int compositeCount = 0;
        for (double val : arr) {
            int num = (int) val;
            if (isComposite(num)) {
                compositeCount++;
            }
        }

        System.out.println("Number of Composite Numbers = " + compositeCount);
        scanner.close();
    }

    public static boolean isComposite(int num) {
        if (num <= 3) {
            return false;
        }
        for (int i = 2; i <= Math.sqrt(num); i++) {
            if (num % i == 0) {
                return true;
            }
        }
        return false;
    }
}
