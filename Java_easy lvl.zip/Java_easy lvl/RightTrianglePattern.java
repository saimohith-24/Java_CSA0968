import java.util.Scanner;

public class RightTrianglePattern {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("n = ");
        if (scanner.hasNextInt()) {
            int n = scanner.nextInt();
            for (int i = 1; i <= n; i++) {
                // Print leading double spaces for alignment
                for (int j = 1; j <= n - i; j++) {
                    System.out.print("  ");
                }
                // Print stars separated by spaces
                for (int j = 1; j <= i; j++) {
                    System.out.print("*" + (j < i ? " " : ""));
                }
                System.out.println();
            }
        }
        scanner.close();
    }
}
