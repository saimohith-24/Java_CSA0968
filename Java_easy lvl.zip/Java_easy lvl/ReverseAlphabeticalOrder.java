import java.util.Scanner;
import java.util.Arrays;

public class ReverseAlphabeticalOrder {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the word: ");
        if (scanner.hasNextLine()) {
            String word = scanner.nextLine().trim();
            char[] chars = word.toUpperCase().toCharArray();
            // Sort in ascending order
            Arrays.sort(chars);
            // Print in reverse order (descending)
            System.out.print("Alphabetical Order: ");
            for (int i = chars.length - 1; i >= 0; i--) {
                System.out.print(chars[i] + (i > 0 ? " " : ""));
            }
            System.out.println();
        }
        scanner.close();
    }
}
