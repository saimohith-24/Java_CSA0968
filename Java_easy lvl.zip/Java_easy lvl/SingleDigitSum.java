import java.util.Scanner;

public class SingleDigitSum {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter N value: ");
        if (!scanner.hasNextInt()) {
            System.out.println("Invalid Input");
            scanner.close();
            return;
        }
        int n = scanner.nextInt();
        if (n <= 0) {
            System.out.println("Invalid Input");
            scanner.close();
            return;
        }

        System.out.print("Enter " + n + " digit numbers: ");
        String numberStr = scanner.next().trim();

        // Validate that string has length exactly n and contains only digits
        if (numberStr.length() != n || !numberStr.matches("\\d+")) {
            System.out.println("Invalid Input");
            scanner.close();
            return;
        }

        // Sum of digits until single digit
        long sum = 0;
        for (char c : numberStr.toCharArray()) {
            sum += (c - '0');
        }

        while (sum >= 10) {
            long tempSum = 0;
            long temp = sum;
            while (temp > 0) {
                tempSum += (temp % 10);
                temp /= 10;
            }
            sum = tempSum;
        }

        System.out.println("Single digit sum = " + sum);
        scanner.close();
    }
}
