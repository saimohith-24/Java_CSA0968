import java.util.Scanner;

public class SkipNumbers {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("M = ");
        if (!scanner.hasNextInt()) {
            System.out.println("Invalid Input");
            scanner.close();
            return;
        }
        int m = scanner.nextInt();
        
        System.out.print("N = ");
        if (!scanner.hasNextInt()) {
            System.out.println("Invalid Input");
            scanner.close();
            return;
        }
        int n = scanner.nextInt();
        
        System.out.print("K = ");
        if (!scanner.hasNextInt()) {
            System.out.println("Invalid Input");
            scanner.close();
            return;
        }
        int k = scanner.nextInt();
        
        if (k < 0) {
            System.out.println("Invalid Input");
            scanner.close();
            return;
        }

        int step = k + 1;
        boolean first = true;
        if (m <= n) {
            for (int i = m; i <= n; i += step) {
                if (!first) {
                    System.out.print(", ");
                }
                System.out.print(i);
                first = false;
            }
        } else {
            for (int i = m; i >= n; i -= step) {
                if (!first) {
                    System.out.print(", ");
                }
                System.out.print(i);
                first = false;
            }
        }
        System.out.println();
        scanner.close();
    }
}
